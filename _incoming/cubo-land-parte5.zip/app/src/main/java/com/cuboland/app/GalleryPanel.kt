package com.cuboland.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Painel da galeria de blocos: ao entrar no mapa abre sozinho, o jogador escolhe a categoria (e, se quiser, só uma seção dela)
 * e o mapa é regerado só com isso. O botão CATEGORIAS, no alto da tela, abre o painel de novo a qualquer hora.
 * onPick(categoria, seção, extra): categoria/seção = índices de World.galleryMenu (seção -1 = todas); extra = World.GAL_*.
 */
class GalleryPanel(
    private val act: Activity,
    private val menu: List<Pair<World.GalCat, List<World.GalSec>>>,
    private val onOpen: () -> Unit,
    private val onClose: () -> Unit,
    private val onPick: (cat: Int, sec: Int, extra: Int) -> Unit
) {
    val view = FrameLayout(act)
    val fab: Button
    var isOpen = false; private set
    private var busy = false

    private val title = TextView(act)
    private val sub = TextView(act)
    private val backBtn: Button
    private val closeBtn: Button
    private val body = LinearLayout(act)
    private val gold = Color.rgb(255, 214, 120)

    private val catColors = intArrayOf(Color.rgb(90, 200, 90), Color.rgb(224, 84, 72), Color.rgb(240, 120, 180), Color.rgb(84, 144, 232), Color.rgb(150, 150, 160))

    init {
        view.visibility = View.GONE
        view.isClickable = true; view.isFocusable = true
        view.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(20, 25, 34), Color.rgb(9, 11, 17))).apply { alpha = 246 }

        val col = LinearLayout(act); col.orientation = LinearLayout.VERTICAL
        val wpx = act.resources.displayMetrics.widthPixels
        val colW = minOf(wpx - act.dp(24), act.dp(760))
        view.addView(col, FrameLayout.LayoutParams(colW, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER_HORIZONTAL).apply { topMargin = act.dp(8); bottomMargin = act.dp(8) })

        // cabeçalho: voltar | título | fechar
        val head = LinearLayout(act); head.orientation = LinearLayout.HORIZONTAL; head.gravity = Gravity.CENTER_VERTICAL
        backBtn = small("← Voltar", Color.rgb(150, 150, 160)) { }
        closeBtn = small("Fechar ✕", Color.rgb(224, 84, 72)) { if (!busy) close() }
        title.setTextColor(gold); title.textSize = 19f; title.typeface = act.mcFont(); title.gravity = Gravity.CENTER
        title.setShadowLayer(0.5f, act.dp(2).toFloat(), act.dp(2).toFloat(), Color.rgb(40, 28, 20))
        head.addView(backBtn, LinearLayout.LayoutParams(act.dp(104), ViewGroup.LayoutParams.WRAP_CONTENT))
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(closeBtn, LinearLayout.LayoutParams(act.dp(104), ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(head)
        sub.setTextColor(Color.rgb(176, 184, 198)); sub.textSize = 13f; sub.gravity = Gravity.CENTER
        sub.setPadding(0, act.dp(4), 0, act.dp(6))
        col.addView(sub)

        body.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(act); sv.addView(body); sv.isVerticalScrollBarEnabled = false
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        fab = small("CATEGORIAS", Color.rgb(255, 170, 60)) { open() }
        fab.textSize = 13f
    }

    /** posição do botão flutuante (centro, no alto) */
    fun fabParams() = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = act.dp(6) }

    private fun small(text: String, color: Int, click: () -> Unit): Button {
        val b = act.btn(text, color, click)
        b.textSize = 13f; b.minHeight = act.dp(40); b.minimumHeight = act.dp(40); b.setPadding(act.dp(8), act.dp(4), act.dp(8), act.dp(4))
        return b
    }

    fun open() {
        if (isOpen) return
        isOpen = true; busy = false
        view.visibility = View.VISIBLE; fab.visibility = View.GONE
        onOpen()
        showCats()
    }

    /** botão voltar do aparelho: fecha o painel, menos enquanto monta o mapa */
    fun onBack() { if (!busy) close() }

    fun close() {
        if (!isOpen) return
        isOpen = false; busy = false
        view.visibility = View.GONE; fab.visibility = View.VISIBLE
        onClose()
    }

    private fun rounded(fill: Int, stroke: Int, radiusDp: Int, strokeDp: Int = 2): GradientDrawable {
        val g = GradientDrawable(); g.setColor(fill); g.cornerRadius = act.dp(radiusDp).toFloat(); g.setStroke(act.dp(strokeDp), stroke); return g
    }

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean = false, font: Boolean = true): TextView {
        val t = TextView(act); t.text = text; t.textSize = sizeSp; t.setTextColor(color)
        if (font) t.typeface = act.mcFont() else t.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        return t
    }

    /** cartão tocável: selo colorido à esquerda, título, subtítulo e seta */
    private fun card(titleT: String, subT: String, accent: Int, badge: String, click: () -> Unit): View {
        val row = LinearLayout(act); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        row.background = rounded(Color.rgb(32, 37, 46), accent, 14)
        row.setPadding(act.dp(10), act.dp(10), act.dp(12), act.dp(10))
        val b = TextView(act); b.text = badge; b.textSize = 18f; b.typeface = act.mcFont(); b.gravity = Gravity.CENTER
        b.setTextColor(Color.rgb(24, 24, 30)); b.background = rounded(accent, accent, 10, 0)
        row.addView(b, LinearLayout.LayoutParams(act.dp(46), act.dp(46)))
        val tc = LinearLayout(act); tc.orientation = LinearLayout.VERTICAL
        tc.addView(label(titleT, 15f, Color.WHITE))
        if (subT.isNotEmpty()) tc.addView(label(subT, 12f, Color.rgb(176, 184, 198), font = false))
        row.addView(tc, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = act.dp(12) })
        row.addView(label("›", 26f, accent, bold = true, font = false))
        row.isClickable = true
        row.setOnClickListener { click() }
        row.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> v.alpha = 0.65f
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> v.alpha = 1f
            }
            false
        }
        return row
    }

    private fun addGrid(items: List<View>, cols: Int) {
        var i = 0
        while (i < items.size) {
            val row = LinearLayout(act); row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until cols) {
                val v = items.getOrNull(i + k)
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); lp.setMargins(act.dp(5), act.dp(5), act.dp(5), act.dp(5))
                row.addView(v ?: View(act), lp)
            }
            body.addView(row)
            i += cols
        }
    }

    private fun heading(text: String) {
        val sp = label(text, 13f, gold); sp.setPadding(act.dp(8), act.dp(14), 0, act.dp(2)); body.addView(sp)
    }

    private fun cols() = if (act.resources.displayMetrics.widthPixels / act.resources.displayMetrics.density > 700) 2 else 1

    private fun pick(cat: Int, sec: Int, extra: Int, what: String) {
        if (busy) return
        busy = true
        body.removeAllViews(); backBtn.visibility = View.INVISIBLE; closeBtn.visibility = View.INVISIBLE
        title.text = "Montando a sala..."; sub.text = what
        val t = label("Carregando os blocos no mapa, só um instante", 15f, Color.WHITE); t.gravity = Gravity.CENTER
        t.setPadding(0, act.dp(40), 0, 0)
        body.addView(t)
        onPick(cat, sec, extra)
    }

    /** passo 1: categorias e vitrines */
    private fun showCats() {
        busy = false
        body.removeAllViews(); backBtn.visibility = View.INVISIBLE; closeBtn.visibility = View.VISIBLE
        title.text = "GALERIA DE BLOCOS"; sub.text = "Escolha uma categoria, depois um tipo de bloco"
        heading("BLOCOS")
        val cs = ArrayList<View>()
        for ((i, p) in menu.withIndex()) {
            val c = p.first
            cs.add(card(c.name, "${p.second.size} tipos  -  ${c.ids.size} blocos", catColors[i % catColors.size], c.name.take(1).uppercase()) { showSecs(i) })
        }
        addGrid(cs, cols())
        heading("PASSEIOS")
        val ex = ArrayList<View>()
        ex.add(card("MANSÃO", "casa completa com móveis, garagem e piscina", Color.rgb(255, 190, 80), "M") { pick(-1, -1, World.GAL_HOUSE, "Mansão") })
        ex.add(card("ÁRVORES", "todas as árvores plantadas", Color.rgb(90, 200, 90), "A") { pick(-1, -1, World.GAL_TREES, "Galeria de árvores") })
        ex.add(card("VEÍCULOS", "pista para testar os carros", Color.rgb(212, 60, 60), "V") { pick(-1, -1, World.GAL_CAR, "Teste de veículos") })
        addGrid(ex, cols())
    }

    /** passo 2: tipos de bloco da categoria (cada um vira uma sala de exposição) */
    private fun showSecs(ci: Int) {
        val (cat, secs) = menu[ci]
        body.removeAllViews(); backBtn.visibility = View.VISIBLE; closeBtn.visibility = View.VISIBLE
        backBtn.setOnClickListener { showCats() }
        title.text = cat.name; sub.text = "Galeria  ›  ${cat.name}"
        val color = catColors[ci % catColors.size]
        val cs = secs.map { s ->
            val pages = (s.count + Gallery.PER_PAGE - 1) / Gallery.PER_PAGE
            val subT = if (pages > 1) "${s.count} blocos  -  $pages partes" else "${s.count} blocos"
            card(s.title, subT, color, s.title.take(1).uppercase()) {
                if (pages > 1) showPages(ci, s, pages) else pick(ci, s.idx, World.GAL_PAGE, cat.name + " - " + s.title)
            }
        }
        addGrid(cs, cols())
    }

    /** passo 3 (só tipos grandes): escolher a parte, 24 blocos por vez */
    private fun showPages(ci: Int, s: World.GalSec, pages: Int) {
        val cat = menu[ci].first
        body.removeAllViews(); backBtn.visibility = View.VISIBLE; closeBtn.visibility = View.VISIBLE
        backBtn.setOnClickListener { showSecs(ci) }
        title.text = s.title; sub.text = "Galeria  ›  ${cat.name}  ›  ${s.title}"
        val color = catColors[ci % catColors.size]
        val cs = (0 until pages).map { pg ->
            val a = pg * Gallery.PER_PAGE + 1; val z = minOf(s.count, (pg + 1) * Gallery.PER_PAGE)
            card("Parte ${pg + 1}", "blocos $a a $z", color, "${pg + 1}") { pick(ci, s.idx, World.GAL_PAGE + pg, cat.name + " - " + s.title + " (parte ${pg + 1})") }
        }
        addGrid(cs, cols())
    }
}
