package com.cuboland.app

import android.opengl.Matrix
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Personagem no formato do Minecraft (Steve/Alex): cabeça 8x8x8, corpo 8x12x4, braços 4x12x4 (3 de largura nas meninas), pernas 4x12x4.
 * 1 pixel = 1,8/32 de bloco: o boneco tem 1,8 de altura e 0,6 de largura, igual ao jogador do Minecraft.
 * Cabelo, roupas, chapéus e acessórios são camadas de caixas por cima do corpo (como a "segunda camada" da skin do Minecraft).
 * Usa os mesmos estados de animação (Anim) do boneco antigo: andar, correr, pular, nadar, voar, agachar, sentar, deitar, golpe, item na mão.
 */
class McChar {
    private var bx: BoxFn = { _, _, _, _, _, _, _, _, _, _, _, _, _ -> }
    private val t1 = FloatArray(16); private val t3 = FloatArray(16); private val t4 = FloatArray(16)
    private val r2 = FloatArray(16); private val bm = FloatArray(16); private val hm = FloatArray(16)
    private val legM = arrayOf(FloatArray(16), FloatArray(16))
    private val armM = arrayOf(FloatArray(16), FloatArray(16))

    /**
     * Camada de profundidade da caixa que está sendo desenhada (0 = pele; roupas e detalhes sobem). O renderer usa isso num polygon offset:
     * assim o que vem por cima (olho sobre rosto, botão sobre camisa, bainha sobre manga) sempre ganha, em qualquer distância e em qualquer GPU,
     * sem as faces "brigarem" (z-fighting).
     */
    @JvmField var layer = 0
    private var layerTop = 0
    @JvmField var layerHook: ((Int) -> Unit)? = null
    private fun lay(from: Int, to: Int) { layer = from; layerTop = to }

    private fun piv(out: FloatArray, parent: FloatArray, px: Float, py: Float, pz: Float, rx: Float = 0f, ry: Float = 0f, rz: Float = 0f) {
        System.arraycopy(parent, 0, out, 0, 16)
        Matrix.translateM(out, 0, px, py, pz)
        if (rz != 0f) Matrix.rotateM(out, 0, rz, 0f, 0f, 1f)
        if (ry != 0f) Matrix.rotateM(out, 0, ry, 0f, 1f, 0f)
        if (rx != 0f) Matrix.rotateM(out, 0, rx, 1f, 0f, 0f)
    }

    private fun swim01(an: Anim) = if (an.swim > 0.2f) 1f else 0f
    private fun lite(c: Int, k: Float) = mixC(c, 0xFFFFFF, k)
    private fun lp(a: Float, b: Float, k: Float) = a + (b - a) * k
    private fun sm01(x: Float) = if (x <= 0f) 0f else if (x >= 1f) 1f else x * x * (3f - 2f * x)

    companion object {
        private val STROKE_KF = arrayOf(floatArrayOf(26f, -10f, -6f), floatArrayOf(52f, -18f, -26f), floatArrayOf(84f, -30f, -62f),
            floatArrayOf(64f, -42f, -72f), floatArrayOf(26f, -10f, -6f), floatArrayOf(26f, -10f, -6f))
        private val STROKE_T = floatArrayOf(0f, 0.22f, 0.46f, 0.68f, 0.92f, 1f)
        private fun armIk(yaw: Float, ev: Float, s: Float, out: FloatArray) {
            val y = Math.toRadians(yaw.toDouble()).toFloat(); val e = Math.toRadians(ev.toDouble()).toFloat()
            val dx = s * sin(y) * cos(e); val dy = cos(y) * cos(e); val dz = -sin(e)
            val h = sqrt(dx * dx + dy * dy)
            var rx = Math.toDegrees(atan2(-dz, -h).toDouble()).toFloat(); if (rx > 0f) rx -= 360f
            out[0] = rx; out[1] = Math.toDegrees(atan2(-dx, dy).toDouble()).toFloat()
        }
        const val U = 0.05625f
        private val HAIR_BK = floatArrayOf(5f, 4f, 9f, 6f, 6f, 6f, 16f, 8f, 3f, 6f, 5f, 5f, 4f, 0.8f, 1f, 5f, 14f, 6f, 5f, 5f, 5f, 3f, 4f, 4f, 6f, 6f, 8f, 11f, 5f, 5f, 5f, 10f, 16f, 12f, 13f, 14f, 7f, 1.5f, 6f, 6f, 4f, 8f, 6f, 6f, 15f, 7f, 7f, 13f, 10f, 6f)
        private val HAIR_SL = floatArrayOf(3f, 2.5f, 9f, 5f, 4f, 4f, 12f, 6f, 1.5f, 4f, 3f, 3f, 2.5f, 0.5f, 0.5f, 3.5f, 12f, 4f, 3f, 3f, 3f, 1.5f, 2f, 2f, 4f, 5f, 6f, 3f, 3f, 4f, 3f, 6f, 12f, 10f, 10f, 10f, 5f, 1f, 6f, 4f, 3f, 8f, 4f, 4f, 11f, 5f, 5f, 9f, 8f, 4f)
        private val HAIR_BG = intArrayOf(1, 5, 3, 2, 1, 2, 3, 2, 7, 4, 5, 1, 5, 0, 0, 6, 3, 2, 2, 2, 2, 1, 4, 1, 2, 0, 3, 1, 1, 6, 0, 5, 3, 2, 2, 2, 4, 0, 3, 2, 4, 4, 1, 0, 3, 4, 2, 2, 2, 2)
        private val HAIR_TP = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 1f, 0f, 1f, 2f, 2f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0.5f, 0f, 3f, 2f, 4f, 0f, 0f, 0f, 0f, 1f, 1f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)
        private val HAIR_EXT = intArrayOf(0, 1, 0, 2, 3, 4, 0, 5, 0, 0, 1, 6, 23, 0, 7, 0, 0, 8, 9, 10, 11, 0, 0, 6, 12, 13, 14, 0, 15, 0, 0, 1, 0, 5, 12, 14, 0, 0, 0, 16, 0, 0, 3, 4, 12, 18, 19, 20, 12, 22)
   // 1 pixel do Minecraft em blocos (1,8 / 32)
    }

    /** root = origem nos pés. handOut = matriz da mão direita (pra segurar item). */
    fun draw(boxIn: BoxFn, root: FloatArray, an: Anim, handOut: FloatArray?) {
        var zf = 0
        layer = 0; layerTop = 0
        bx = { m, px, py, pz, rx, ry, sx, sy, sz, oy, col, a, rz ->
            val k = 1f + min(zf, 300) * 0.00004f; zf++   // cada caixa nova fica um tiquinho maior
            layerHook?.invoke(layer)
            if (layer < layerTop) layer++   // dentro de uma seção, cada caixa nova fica por cima da anterior
            boxIn(m, px, py, pz, rx, ry, sx * k, sy * k, sz * k, oy, col, a, rz)
        }
        val t = an.t
        val L = Look.v
        val girl = L[Look.GENDER] == 1
        val skin = Look.skin(); val skinD = shadeC(skin, 0.9f)
        val tc = Look.pal(Look.TOPC); val top = L[Look.TOP]
        val bc = Look.pal(Look.BOTTOMC); val bot = L[Look.BOTTOM]
        val white = 0xF4F4F4
        val full = top == 2 || top == 10 || top == 11 || top == 15   // roupas longas (cobrem as pernas)
        val overalls = top == 6
        val skirtBot = (bot == 2 || bot == 5) && !full && !overalls
        val wide = bot == 4 && !full && !overalls   // hakama: perna larga
        val bw = if (girl) 0.44f else 0.48f
        val gold = 0xFFD060
        val trim = lite(tc, 0.35f); val dark = shadeC(tc, 0.78f)

        // ================= ANIMAÇÃO =================
        val mv = an.move.coerceIn(0f, 1f); val li = an.lie.coerceIn(0f, 1f); val rn = an.run.coerceIn(0f, 1f) * (1f - li); val ph = an.phase   // rastejando não usa o modo corrida
        val swimming = an.swim > 0.2f
        val fl = if (swimming) 0f else an.fly.coerceIn(0f, 1f); val fm = an.flySpd.coerceIn(0f, 1f)
        val ab = if (swimming) 0f else an.airA.coerceIn(0f, 1f) * (1f - fl)
        val chg = an.charge.coerceIn(0f, 1f)
        val vk = (an.vy / 7f).coerceIn(-1f, 1f)
        val air = ab > 0.02f
        val fs = (1f - vk) * 0.5f          // 0 subindo .. 1 caindo (contínuo, sem trancos)
        val dv = an.dive.coerceIn(0f, 1f)
        val land = an.landT.coerceIn(0f, 1f)
        val landBig = (an.landT - 1f).coerceIn(0f, 0.5f) * 2f   // aterrissagem de super pulo: afunda mais e demora mais pra levantar
        val jch = an.jch.coerceIn(0f, 1f); val sj = an.sj.coerceIn(0f, 1f)   // carregando o pulo / no ar de um super pulo
        val rs = sm01(vk); val fa2 = sm01(-vk); val ap = (1f - rs - fa2).coerceIn(0f, 1f)   // pesos contínuos: subindo / topo / caindo (sem trancos)
        val leadL = if (sin(ph) < 0f) 1f else 0f   // a perna que estava na frente no passo é a que puxa o joelho no pulo
        val shiver = jch * jch * jch * sin(t * 62f) * 1.8f   // carga cheia: o corpo treme
        val legSq = 0.30f * jch + 0.22f * land + 0.12f * landBig   // pernas amassam (agachar de desenho animado)
        val dashW = max(an.dash.coerceIn(0f, 1f), an.imp.coerceIn(0f, 1f)) * (1f - swim01(an))
        val uImp = 1f - an.imp.coerceIn(0f, 1f)
        val wind = if (an.imp <= 0f) 0f else if (uImp < 0.4f) uImp / 0.4f else max(0f, 1f - (uImp - 0.4f) / 0.25f)
        // subindo / descendo no voo (suave, pela velocidade vertical): subir = corpo reto, braços em V pra cima, pernas juntas e soltas; descer = braços abertos, pernas abertas planando
        val fvy = an.vy / 5f
        val fu = if (swimming) 0f else sm01((fvy - 0.12f) / 0.7f) * fl * (1f - dashW)
        val fd = if (swimming) 0f else sm01((-fvy - 0.12f) / 0.7f) * fl * (1f - dashW)
        val atk = an.atk; val atking = atk < 1f
        val stride = if (swimming) 0f else sm01(mv * 2.2f) * (1f - ab) * (1f - fl)   // entra suave (antes: cheio em 0,05s com a fase ainda parada = travada)
        var sw = sin(ph) * (26f + 30f * rn) * stride
        var hipL = sw; var hipR = -sw
        var kneeL = max(0f, -cos(ph)) * (12f + 50f * rn) * stride
        var kneeR = max(0f, cos(ph)) * (12f + 50f * rn) * stride
        val rw = rn * stride   // peso da corrida de verdade (no chão)
        if (rw > 0.001f) {
            // ciclo de corrida: perna de balanço sobe a coxa e dobra o joelho forte (recuperação), apoia à frente absorvendo no joelho e empurra esticando atrás
            fun rHip(p: Float): Float { val s = sin(p); val c = cos(p); return 40f * s - 8f - 10f * max(0f, -c) }
            fun rKnee(p: Float): Float { val s = sin(p); val c = cos(p)
                return 100f * Math.pow(max(0f, -c).toDouble(), 1.25).toFloat() + 24f * max(0f, c) * max(0f, -s) * 1.6f + 7f * max(0f, c) * max(0f, s) }
            hipL = lp(hipL, rHip(ph), rw); hipR = lp(hipR, rHip(ph + 3.1416f), rw)
            kneeL = lp(kneeL, rKnee(ph), rw); kneeR = lp(kneeR, rKnee(ph + 3.1416f), rw)
        }
        if (swimming) {
            val sa = sin(t * 8f); val sb = sin(t * 4.6f); val cb = cos(t * 4.6f)
            // na superfície: pedalada; mergulhado: batida de perna reta (crawl)
            hipL = lp(sb * 26f, sa * 30f, dv); hipR = lp(-sb * 26f, -sa * 30f, dv)
            kneeL = lp(30f + cb * 24f, 8f + sa * 10f, dv); kneeR = lp(30f - cb * 24f, 8f - sa * 10f, dv)
            // acelerando na superfície: as pernas sobem um pouco e batem rápido (pernada de crawl), bem diferente do boiar parado
            val kf = an.swimFast.coerceIn(0f, 1f) * (1f - dv)
            if (kf > 0.001f) {
                val kk = t * 17f; val ks = sin(kk)
                hipL = lp(hipL, 6f + ks * 20f, kf); hipR = lp(hipR, 6f - ks * 20f, kf)
                kneeL = lp(kneeL, 12f + 26f * max(0f, sin(kk + 1.1f)), kf); kneeR = lp(kneeR, 12f + 26f * max(0f, -sin(kk + 1.1f)), kf)
            }
        }
        if (ab > 0.01f) {
            // 3 poses que se misturam pelo vy: pernas quase retas, só um passinho aberto na subida, juntinhas no topo e esticadas descendo (sem chutar pra frente)
            val hLd = rs * lp(-14f, 6f, sj) + ap * lp(-18f, -26f, sj) + fa2 * lp(-8f + sin(t * 9f) * 1.5f, -6f, sj)
            val kLd = rs * lp(10f, 4f, sj) + ap * lp(22f, 34f, sj) + fa2 * lp(4f, 4f, sj)
            val hTr = rs * lp(12f, 8f, sj) + ap * lp(-6f, -20f, sj) + fa2 * lp(6f, 2f, sj)
            val kTr = rs * lp(14f, 6f, sj) + ap * lp(14f, 30f, sj) + fa2 * lp(4f, 4f, sj)
            hipL = lp(hipL, lp(hTr, hLd, leadL), ab); kneeL = lp(kneeL, lp(kTr, kLd, leadL), ab)
            hipR = lp(hipR, lp(hLd, hTr, leadL), ab); kneeR = lp(kneeR, lp(kLd, kTr, leadL), ab)
        }
        if (fl > 0.01f) {
            // voando parado: as duas pernas retas, um pouco abertas (ver splay), com um balanço leve; andando, juntas e esticadas pra trás
            val hov = 1f - fm
            val base = -4f - 12f * fm + sin(t * 1.7f) * 2.5f * hov
            val fkU = sin(t * 6f) * 4f * fu; val fkD = sin(t * 4.6f) * 3f * fd   // subindo: pés batem de leve; descendo: pernas balançam soltas
            val hipT = base + 10f * fu - 12f * fd
            val kneeT = 4f + 3f * fm + 8f * fu + 16f * fd
            hipL = lp(hipL, hipT + fkU + fkD + sin(t * 7f) * 1.2f * fm, fl); hipR = lp(hipR, hipT - fkU - fkD - sin(t * 7f) * 1.2f * fm - sin(t * 1.7f) * 1.5f * hov, fl)
            kneeL = lp(kneeL, kneeT + max(0f, fkU) * 0.8f, fl); kneeR = lp(kneeR, kneeT + max(0f, -fkU) * 0.8f, fl)
        }
        if (dashW > 0.001f && fl > 0.01f) {
            val fk2 = sin(t * 14f) * 1.5f
            hipL = lp(hipL, 8f + fk2 + 20f * wind, dashW); hipR = lp(hipR, 8f + fk2 + 20f * wind, dashW)
            kneeL = lp(kneeL, 8f + 55f * wind, dashW); kneeR = lp(kneeR, 8f + 55f * wind, dashW)
        }
        val dch = an.dch.coerceIn(0f, 1f); val dst = an.dst.coerceIn(0f, 1f); val tuck = dch * (1f - dst)
        val lw0 = an.launch.coerceIn(0f, 1f); val lwE = lw0 * lw0 * (3f - 2f * lw0)
        if (tuck > 0.001f) {   // carregando o dash aéreo: as duas pernas encolhidas contra o peito (joelhos pra frente), tomando impulso
            hipL = lp(hipL, -74f, tuck); hipR = lp(hipR, -66f, tuck)
            kneeL = lp(kneeL, 108f, tuck); kneeR = lp(kneeR, 100f, tuck)
        }
        val tkw = an.trk.coerceIn(0f, 1f); val tkk = an.trkK.toInt(); val tkFast = an.trkF > 0.5f
        val tkFlip = tkk == 1 || tkk == 2 || (!tkFast && (tkk == 12 || tkk == 13))   // mortal / giro de costas: corpo encolhido
        val tkSpin = tkk == 5 && !tkFast   // pirueta: braços pro alto, bailarino
        val tkSuper = tkFast && !tkFlip   // voo rápido (tonel/espiral): esticado, braços à frente, pose de super-herói
        val tkP = an.trkP.coerceIn(0f, 1f)
        // fases da manobra: preparação (agacha, braços atrás) -> impulso (estica, braços pro alto) -> grupado/pose do giro -> abertura (prepara a queda)
        val wCr = sin(3.1416f * (tkP / 0.17f).coerceIn(0f, 1f)) * tkw * (1f - 0.7f * (if (tkFast) 1f else 0f))
        val wLa = sin(3.1416f * ((tkP - 0.09f) / 0.24f).coerceIn(0f, 1f)) * tkw
        val wTu = sm01((tkP - 0.20f) / 0.12f) * (1f - sm01((tkP - 0.68f) / 0.14f)) * tkw
        val wOp = sm01((tkP - 0.66f) / 0.16f) * (1f - sm01((tkP - 0.94f) / 0.06f)) * tkw
        val wBd = sm01((tkP - 0.06f) / 0.20f) * (1f - sm01((tkP - 0.84f) / 0.14f)) * tkw
        if (tkw > 0.001f) {
            hipL = lp(hipL, -26f, wCr); hipR = lp(hipR, -20f, wCr); kneeL = lp(kneeL, 58f, wCr); kneeR = lp(kneeR, 50f, wCr)
            hipL = lp(hipL, 4f, wLa); hipR = lp(hipR, 2f, wLa); kneeL = lp(kneeL, 3f, wLa); kneeR = lp(kneeR, 3f, wLa)
            if (tkFlip) {   // grupado de verdade (joelhos no peito) e depois abre as pernas pra baixo, uma à frente da outra, pra pousar
                hipL = lp(hipL, -76f, wTu); hipR = lp(hipR, -68f, wTu); kneeL = lp(kneeL, 116f, wTu); kneeR = lp(kneeR, 108f, wTu)
                hipL = lp(hipL, -16f, wOp); hipR = lp(hipR, 6f, wOp); kneeL = lp(kneeL, 26f, wOp); kneeR = lp(kneeR, 8f, wOp)
            } else if (tkSpin) {   // pirueta: perna de apoio esticada e a outra em "passé" (pé no joelho)
                hipL = lp(hipL, 3f, wBd); kneeL = lp(kneeL, 3f, wBd); hipR = lp(hipR, -40f, wBd); kneeR = lp(kneeR, 100f, wBd)
            } else if (tkSuper) {   // voo rápido: corpo reto como flecha, pernas juntas
                hipL = lp(hipL, 5f, wBd); hipR = lp(hipR, 5f, wBd); kneeL = lp(kneeL, 4f, wBd); kneeR = lp(kneeR, 4f, wBd)
            } else {   // parafuso/saca-rolha: corpo em arco (pernas atrás, joelhos dobrados)
                hipL = lp(hipL, 14f, wBd); hipR = lp(hipR, 10f, wBd); kneeL = lp(kneeL, 34f, wBd); kneeR = lp(kneeR, 28f, wBd)
            }
        }
        if (dst > 0.001f) {   // pisada no ar: a perna direita estica de uma vez pra trás (empurra o ar), a esquerda continua dobrada
            hipR = lp(hipR, 14f, dst); kneeR = lp(kneeR, 2f, dst)
            hipL = lp(hipL, -34f, dst * 0.85f); kneeL = lp(kneeL, 70f, dst * 0.85f)
        }
        if (lwE > 0.001f) {   // decolagem do super pulo: pernas juntinhas e esticadas, relaxando pra pose de voo
            hipL = lp(hipL, 4f, lwE * 0.7f); hipR = lp(hipR, 4f, lwE * 0.7f)
            kneeL = lp(kneeL, 8f, lwE * 0.7f); kneeR = lp(kneeR, 6f, lwE * 0.7f)
        }
        if (land > 0f) {
            hipL += (-8f - hipL) * land; hipR += (4f - hipR) * land
            kneeL += (6f - kneeL) * land; kneeR += (6f - kneeR) * land
        }
        if (full || wide || overalls.not() && skirtBot) {   // roupa longa/saia: pernas não atravessam o tecido
            val kk = if (full) 0.5f else if (wide) 0.6f else 0.85f   // a saia agora acompanha as coxas, então pode balançar bem mais
            val cap = if (full) 13f else if (wide) 17f else 26f
            hipL = (hipL * kk).coerceIn(-cap, cap); hipR = (hipR * kk).coerceIn(-cap, cap)
            kneeL = (kneeL * kk).coerceIn(0f, if (full) 24f else if (wide) 36f else 60f); kneeR = (kneeR * kk).coerceIn(0f, if (full) 24f else if (wide) 36f else 60f)
        }
        // posturas: agachar (pernas dobradas, tronco inclinado), sentar (pernas à frente, no chão), deitar (de costas)
        val cr = an.crouch.coerceIn(0f, 1f); val si = an.sit.coerceIn(0f, 1f)
        var qLegL = 0f; var qLegR = 0f
        if (cr > 0f) { hipL = lp(hipL, -62f + sw * 0.4f, cr); hipR = lp(hipR, -62f - sw * 0.4f, cr); kneeL = lp(kneeL, 72f + kneeL * 0.3f, cr); kneeR = lp(kneeR, 72f + kneeR * 0.3f, cr) }
        if (si > 0f) { val br = sin(t * 1.6f) * 2f; hipL = lp(hipL, -87f + br, si); hipR = lp(hipR, -87f + br, si); kneeL = lp(kneeL, 4f, si); kneeR = lp(kneeR, 4f, si) }
        val bt = an.bent.coerceIn(0f, 1f)
        if (bt > 0f) { hipL = lp(hipL, -72f, bt); hipR = lp(hipR, -72f, bt); kneeL = lp(kneeL, 62f, bt); kneeR = lp(kneeR, 62f, bt) }
        // ---- SKATISTA: perna da frente = hipR/kneeR (sd>0, +X), perna de trás = hipL/kneeL (sd<0, -X); rz abre os pés ao longo da prancha ----
        val skw = an.sk.coerceIn(0f, 1f)
        var spF = 0f; var spR = 0f; var pushFace = 0f
        if (skw > 0.001f) {
            val kSc = an.crouch.coerceIn(0f, 1f); val kPop = an.skPop.coerceIn(0f, 1f); val kLand = an.skLand.coerceIn(0f, 1f)
            val kGr = an.skGrab.coerceIn(0f, 1f); val kFl = an.skFlip.coerceIn(0f, 1f); val kGd = an.skGrind.coerceIn(0f, 1f)
            val kMan = an.skMan.coerceIn(0f, 1f); val kPw = an.skPush.coerceIn(0f, 1f); val kFace = an.skFace.coerceIn(0f, 1f)
            val sway = sin(an.t * 1.9f) * 2f
            var fH = -14f - 40f * kSc - 14f * kLand + sway; var fK = 24f + 46f * kSc + 24f * kLand
            var rH = -10f - 40f * kSc - 14f * kLand - sway; var rK = 28f + 46f * kSc + 26f * kLand
            var sF = 14f + 4f * kSc; var sR = 14f + 4f * kSc
            fH = lp(fH, -4f, kPop * 0.85f); fK = lp(fK, 6f, kPop * 0.85f); rH = lp(rH, -2f, kPop * 0.85f); rK = lp(rK, 4f, kPop * 0.85f)   // ollie: pernas esticam
            fH = lp(fH, -30f, kMan); fK = lp(fK, 20f, kMan); sF = lp(sF, 18f, kMan)                                                         // manual: peso atrás
            sF = lp(sF, 19f, kGd); sR = lp(sR, 19f, kGd)                                                                                    // grind: base larga
            fH = lp(fH, -34f, kFl * 0.8f); fK = lp(fK, 58f, kFl * 0.8f); rH = lp(rH, -22f, kFl * 0.8f); rK = lp(rK, 70f, kFl * 0.8f)       // flip: pernas recolhidas
            pushFace = kFace * kPw
            if (kPw > 0.001f) {   // arrancada: um pé permanece na prancha e o outro toca o chão para impulsionar para trás
                val phase = an.skPushPh.coerceIn(0f, 1f)
                val h2: Float; val k2: Float; val s2: Float
                when {
                    phase < 0.18f -> {
                        val e = phase / 0.18f
                        val smooth = e * e * (3f - 2f * e)
                        // Tira o pé traseiro da prancha e coloca-o ao lado, perto do chão.
                        s2 = 14f + 18f * smooth
                        h2 = -6f + 8f * smooth
                        k2 = 12f + 12f * smooth
                    }
                    phase < 0.62f -> {
                        val e = (phase - 0.18f) / 0.44f
                        val drive = e * e * (3f - 2f * e)
                        // Apoia e estende para trás, gerando o impulso.
                        s2 = 32f - 5f * drive
                        h2 = 2f + 38f * drive
                        k2 = 24f - 8f * drive
                    }
                    phase < 0.82f -> {
                        val e = ((phase - 0.62f) / 0.20f).coerceIn(0f, 1f)
                        val smooth = e * e * (3f - 2f * e)
                        // Recolhe o pé do chão, dobrando a perna antes de voltar à prancha.
                        s2 = 27f - 9f * smooth
                        h2 = 40f - 48f * smooth
                        k2 = 16f + 34f * sin(e * 3.1416f)
                    }
                    else -> {
                        val e = ((phase - 0.82f) / 0.18f).coerceIn(0f, 1f)
                        val smooth = e * e * (3f - 2f * e)
                        s2 = 18f - 4f * smooth
                        h2 = -8f - 4f * smooth
                        k2 = 50f - 24f * smooth
                    }
                }
                rH = lp(rH, h2, kPw); rK = lp(rK, k2, kPw); sR = lp(sR, s2, kPw)
                // Perna da frente fica estável e só flexiona para receber o peso do corpo.
                fH = lp(fH, -18f, kPw); fK = lp(fK, 26f, kPw)
            }
            fH = lp(fH, -105f, kGr); fK = lp(fK, 135f, kGr); rH = lp(rH, -95f, kGr); rK = lp(rK, 130f, kGr); sF = lp(sF, 7f, kGr); sR = lp(sR, 7f, kGr)   // grab: joelhos no peito
            hipR = lp(hipR, fH, skw); kneeR = lp(kneeR, fK, skw); hipL = lp(hipL, rH, skw); kneeL = lp(kneeL, rK, skw)
            spF = sF * skw; spR = sR * skw
        }
        if (li > 0f) { val mc = min(1f, mv * 3f); qLegL = (0.5f + 0.5f * sin(ph + 3.1416f)) * mc; qLegR = (0.5f + 0.5f * sin(ph)) * mc
            hipL = lp(hipL, 2f + 7f * qLegL, li); hipR = lp(hipR, 2f + 7f * qLegR, li)
            kneeL = lp(kneeL, 4f + 26f * qLegL, li); kneeR = lp(kneeR, 4f + 26f * qLegR, li) }
        val drop = 0.12f * cr + 0.545f * si + 0.675f * legSq + 0.14f * tuck + skw * (0.035f + 0.09f * an.skPush.coerceIn(0f, 1f) + 0.2f * an.skGrab.coerceIn(0f, 1f))
        val bob = sin(t * 2f) * 0.012f * (1f - stride) + abs(sin(ph)) * (0.035f + 0.075f * rn) * stride * (1f - 0.85f * li) + fl * (1f - fm) * sin(t * 1.6f) * 0.09f   // pairando: sobe e desce devagar
        val move = stride * (1f + rn * 0.6f) + ab * lp(0.4f, 1.2f, fs)

        System.arraycopy(root, 0, r2, 0, 16)
        Matrix.translateM(r2, 0, 0f, bob - drop, 0f)
        if (an.flip != 0f) {   // cambalhota do super pulo: gira o corpo todo em volta do centro
            Matrix.translateM(r2, 0, 0f, 0.9f, 0f); Matrix.rotateM(r2, 0, an.flip, 1f, 0f, 0f); Matrix.translateM(r2, 0, 0f, -0.9f, 0f)
        }
        if (li > 0.001f) {   // deitado de costas: gira o corpo todo em volta do centro
            Matrix.translateM(r2, 0, 0f, 0.2f * li, -0.7f * li)   // rastejando, de frente (barriga no chão)
            Matrix.rotateM(r2, 0, 90f * li, 1f, 0f, 0f)
        }

        val lean = 30f * an.dash.coerceIn(0f, 1f) * fl - 30f * wind * dashW + 18f * cr + 6f * si + 3f * stride * (1f - li) - 7f * li + 18f * rn * stride + ab * (rs * lp(-4f, 14f, sj) + ap * lp(0f, 30f, sj) + fa2 * lp(7f, 12f, sj)) + 10f * land + 30f * jch + 6f * landBig + fl * (8f + 52f * fm) * (1f - 0.78f * fu) + 14f * fd - 4f * fu - 10f * chg + 22f * tuck + 26f * dst - an.vp * an.dash.coerceIn(0f, 1f) * fl - 24f * lwE + skw * (-10f * an.skMan - 6f * an.skPop + 10f * an.skGrab) +
            (if (atking) 9f * sin(atk * 3.1416f) else 0f)
        val swimK = if (swimming) an.swimFast.coerceIn(0f, 1f) * (1f - dv) else 0f
        val twist = sin(an.swimPh) * 34f * swimK + sin(ph) * (5f + 15f * rn) * stride * (1f - li) + 14f * chg + (if (atking) 18f * sin(atk * 6.2832f) else 0f)
        val roll = sin(ph) * 2.2f * stride * (1f - rn) + 3f * sin(ph) * rn * stride + 8f * li * min(1f, mv * 3f) * sin(ph) + (if (air) 0f else sin(t * 0.9f) * 1.3f * (1f - stride)) + shiver

        // ================= ESQUELETO: quadril em 0,675 (12 px), pescoço em 1,35 (24 px), topo da cabeça em 1,8 =================
        val hipY = 12f * U
        System.arraycopy(r2, 0, bm, 0, 16)
        Matrix.translateM(bm, 0, 0f, hipY, 0f)
        if (roll != 0f) Matrix.rotateM(bm, 0, roll, 0f, 0f, 1f)
        if (twist != 0f) Matrix.rotateM(bm, 0, twist, 0f, 1f, 0f)
        if (lean != 0f) Matrix.rotateM(bm, 0, lean, 1f, 0f, 0f)
        val stretch = ab * rs * (0.025f + 0.05f * sj)   // esticadinha na subida
        val ssx = 1f + 0.06f * land + 0.05f * jch + 0.04f * landBig - stretch * 0.6f
        val ssy = 1f - 0.08f * land - 0.07f * jch - 0.05f * landBig + stretch
        if (ssx != 1f || ssy != 1f) Matrix.scaleM(bm, 0, ssx, ssy, ssx)
        Matrix.translateM(bm, 0, 0f, -hipY, 0f)

        val look = sin(t * 0.55f) * sin(t * 0.23f)
        val hy = if (swimK > 0.01f) -twist * 0.55f + 30f * swimK * sm01(sin(an.swimPh * 0.5f + 0.4f) * 1.6f - 0.3f) else if (stride > 0.1f) -twist * 0.7f else look * 16f * (1f - stride)   // nadando: gira a cabeça pra respirar a cada braçada
        val hnod = -lean * 0.55f + sin(ph * 2f) * (1.8f + 2.2f * rn) * stride + sin(t * 1.3f) * 1.4f * (1f - stride) + ab * (-6f * rs + 6f * fa2) - 10f * jch - an.tilt * lp(0.9f, 0.5f, dv) - 70f * li - 11f * fu + 7f * fd
        val htilt = sin(t * 0.8f) * 2f * (1f - stride)
        System.arraycopy(bm, 0, hm, 0, 16)
        Matrix.translateM(hm, 0, 0f, 24f * U, 0f)
        if (htilt != 0f) Matrix.rotateM(hm, 0, htilt, 0f, 0f, 1f)
        if (hy != 0f) Matrix.rotateM(hm, 0, hy, 0f, 1f, 0f)
        if (hnod != 0f) Matrix.rotateM(hm, 0, hnod, 1f, 0f, 0f)
        val blink = (t % 3.7f) > 3.58f || (t % 6.1f) > 6.0f

        // ================= POSE DOS BRAÇOS (mesma lógica do boneco antigo) =================
        val toolArm = an.hasTool
        val asw = sw * (0.95f + 0.5f * rn)
        var rxL = asw - 4f; var rxR = -asw - 4f   // braço direito (sd<0) balança contra a perna direita
        var elL = -(8f + 6f * stride + 58f * rn * stride); var elR = elL
        var rzL = -(4f + sin(t * 2f) * 1.5f * (1f - stride)); var rzR = -rzL
        val aa = an.atkArm
        val ikL = FloatArray(2); val ikR = FloatArray(2)
        val atkRx = if (an.poseOn) -an.pP * 0.95f else aa
        var ryR = 0f; var ryL = 0f
        if (rw > 0.001f) {   // braços da corrida: cotovelo bem dobrado (mais ainda quando o braço vai à frente), balanço maior à frente que atrás, cruzando de leve pro centro
            val fL = (max(0f, -asw) / 56f).coerceIn(0f, 1f); val fR = (max(0f, asw) / 56f).coerceIn(0f, 1f)
            rxL = lp(rxL, (if (asw < 0f) asw * 1.0f else asw * 0.75f) - 4f, rw); rxR = lp(rxR, (if (asw > 0f) -asw * 1.0f else -asw * 0.75f) - 4f, rw)
            elL = lp(elL, -(58f + 40f * fL), rw); elR = lp(elR, -(58f + 40f * fR), rw)
            rzL = lp(rzL, -(5f - 4.5f * fL), rw); rzR = lp(rzR, 5f - 4.5f * fR, rw)
        }
        if (toolArm) { rxR = -22f + atkRx - sw * 0.25f * (1f - rn * 0.5f); elR = -6f - 6f * rn * stride; rzR = 20f
            if (an.poseOn) { ryR = an.pY * 0.9f; elR = (elR + an.pW * 0.5f).coerceIn(-70f, 10f) } }
        else if (atking || chg > 0.01f) { rxR += atkRx; if (an.poseOn) ryR = an.pY * 0.9f }
        var swimToolA = 0f
        if (swimming) {
            // cabeça fora: braçada alternada e calma (alcança, puxa pra baixo, volta com o cotovelo dobrado). Mergulhado: braçada de peito (V à frente, abre, puxa pros lados e volta).
            val fa = an.swimFast.coerceIn(0f, 1f); val sa = an.swimPh; val pi = 3.1416f   // fa: só acelerando os braços batem
            val tOff = max(0f, an.tilt - 32f) * (1f - dv) * fa   // corpo mais deitado: os braços sobem junto pra continuarem alcançando à frente
            val sl2 = sin(t * 2.3f)
            // sem acelerar: na superfície os bracinhos batem leve pra boiar (parado ou andando); mergulhado os dois braços ficam inclinados pra trás, nas diagonais
            val lSurfX = -25f + sl2 * 14f; val lSurfZ = -(38f + sin(t * 2.3f + 1.2f) * 16f); val lSurfE = -20f + sl2 * 8f
            val diagX = 14f + sin(t * 2.5f) * 3f; val diagZ = 30f + sin(t * 2.5f + 1f) * 3f; val diagE = -6f
            val recL = max(0f, cos(sa)); val recR = max(0f, cos(sa + pi))
            val sXL = lp(lSurfX, -67f - 55f * sin(sa), fa) - tOff; val sXR = lp(lSurfX, -67f - 55f * sin(sa + pi), fa) + atkRx - tOff
            val sZL = lp(lSurfZ, -8f, fa); val sZR = lp(-lSurfZ, 8f, fa)
            val sEL = lp(lSurfE, -(7f + 30f * recL), fa); val sER = lp(lSurfE, -(7f + 30f * recR), fa)
            val sYL = (16f + 10f * recL) * fa; val sYR = -(16f + 10f * recR) * fa
            var e = (sa / 6.2832f) % 1f; if (e < 0f) e += 1f
            var ki = 0; while (ki < 4 && e >= STROKE_T[ki + 1]) ki++
            val ue = (e - STROKE_T[ki]) / (STROKE_T[ki + 1] - STROKE_T[ki]); val u = ue * ue * (3f - 2f * ue)
            val ka = STROKE_KF[ki]; val kb = STROKE_KF[ki + 1]
            val yw = lp(ka[0], kb[0], u); val ev = lp(ka[1], kb[1], u); val dE0 = lp(ka[2], kb[2], u)
            armIk(yw, ev, 1f, ikL); armIk(yw, ev, -1f, ikR)
            val dXL = lp(diagX, ikL[0], fa); val dZL = lp(-diagZ, -ikL[1], fa); val dEL = lp(diagE, dE0, fa)
            val dXR = lp(diagX, ikR[0], fa) + atkRx; val dZR = lp(diagZ, -ikR[1], fa)
            rxL = lp(sXL, dXL, dv); rzL = lp(sZL, dZL, dv); elL = lp(sEL, dEL, dv); ryL = lp(sYL, 0f, dv)
            rxR = lp(sXR, dXR, dv); rzR = lp(sZR, dZR, dv); elR = lp(sER, dEL, dv); ryR = lp(sYR, 0f, dv)
            if (an.poseOn && toolArm) ryR += an.pY * 0.9f
            swimToolA = 0.5f * (-(an.tilt - 14f) - (rxR - atkRx + elR))   // o item segue a mão (metade da compensação): sem atravessar cabeça nem tronco
        }
        if (ab > 0.01f) {
            // braços acompanham as 3 poses: sobem à frente na subida, abrem no topo e ficam abertos pra equilibrar na queda
            val flapA = sin(t * 9f) * 5f * fa2
            val pxA = rs * lp(-62f, -14f, sj) + ap * lp(-22f, -78f, sj) + fa2 * lp(-8f, -10f, sj)
            val pzA = rs * lp(24f, 160f, sj) + ap * lp(62f, 22f, sj) + fa2 * lp(50f, 88f, sj)
            val peA = rs * lp(-12f, -4f, sj) + ap * lp(-8f, -66f, sj) + fa2 * lp(-6f, -8f, sj)
            rxL = lp(rxL, pxA + flapA, ab); rzL = lp(rzL, -pzA, ab); elL = lp(elL, peA, ab)
            // os dois braços iguais (o do item também), com o golpe somado por cima
            rxR = lp(rxR, pxA - flapA + atkRx, ab); rzR = lp(rzR, pzA, ab); elR = lp(elR, peA, ab)
        }
        if (jch > 0.01f) {   // carregando o super pulo: braços jogados pra trás, tomando impulso (o braço do item fica como está)
            val k = min(1f, jch * 2.5f)
            rxL = lp(rxL, 46f * jch + 4f, k); rzL = lp(rzL, -(14f + 10f * jch), k); elL = lp(elL, -(10f + 24f * jch), k)
            if (!toolArm) { rxR = lp(rxR, 46f * jch + 4f, k); rzR = lp(rzR, 14f + 10f * jch, k); elR = lp(elR, -(10f + 24f * jch), k) }
        }
        if (fl > 0.01f) {
            // os dois braços ficam pra baixo, iguais ao do item: só um balanço leve
            val fw = sin(t * 3f) * 4f * (1f - fm)
            val dn = lp(-14f, -26f, fm)
            rxL = lp(rxL, dn + sin(t * 2.6f) * 3f, fl); rzL = lp(rzL, -(16f + fw), fl); elL = lp(elL, -8f, fl)
            if (toolArm) { rxR = lp(rxR, lp(-24f, -40f, fm) + atkRx, fl); rzR = lp(rzR, 20f, fl) }
            else { rxR = lp(rxR, dn - sin(t * 2.6f) * 3f, fl); rzR = lp(rzR, 16f + fw, fl); elR = lp(elR, -8f, fl) }
        }
        if (fu > 0.001f || fd > 0.001f) {   // braços só reagem ao ar, bem de leve: subindo ficam levemente atrás/abertos (arrastados); descendo o ar os levanta um pouquinho
            val sw1 = sin(t * 2.6f) * 3f; val sw2 = sin(t * 2.1f + 1f) * 3f
            rxL = lp(rxL, 16f + sw1, fu * 0.8f); rzL = lp(rzL, -(24f + sw2), fu * 0.8f); elL = lp(elL, -10f, fu * 0.8f)
            rxL = lp(rxL, -10f + sw2, fd * 0.8f); rzL = lp(rzL, -(42f + sw1), fd * 0.8f); elL = lp(elL, -8f, fd * 0.8f)
            if (!toolArm) {
                rxR = lp(rxR, 16f - sw1, fu * 0.8f); rzR = lp(rzR, 24f - sw2, fu * 0.8f); elR = lp(elR, -10f, fu * 0.8f)
                rxR = lp(rxR, -10f - sw2, fd * 0.8f); rzR = lp(rzR, 42f - sw1, fd * 0.8f); elR = lp(elR, -8f, fd * 0.8f)
            }
        }
        if (tkw > 0.001f) {
            rxL = lp(rxL, 38f, wCr); rzL = lp(rzL, -12f, wCr); elL = lp(elL, -8f, wCr)
            rxL = lp(rxL, -172f, wLa); rzL = lp(rzL, -10f, wLa); elL = lp(elL, -4f, wLa)
            if (!toolArm) {
                rxR = lp(rxR, 38f, wCr); rzR = lp(rzR, 12f, wCr); elR = lp(elR, -8f, wCr)
                rxR = lp(rxR, -172f, wLa); rzR = lp(rzR, 10f, wLa); elR = lp(elR, -4f, wLa)
            }
            if (tkFlip) {   // mãos nas canelas no grupado; depois abre os braços pra equilibrar a queda
                rxL = lp(rxL, -72f, wTu); rzL = lp(rzL, -8f, wTu); elL = lp(elL, -98f, wTu)
                rxL = lp(rxL, -22f, wOp); rzL = lp(rzL, -66f, wOp); elL = lp(elL, -6f, wOp)
                if (!toolArm) {
                    rxR = lp(rxR, -72f, wTu); rzR = lp(rzR, 8f, wTu); elR = lp(elR, -98f, wTu)
                    rxR = lp(rxR, -22f, wOp); rzR = lp(rzR, 66f, wOp); elR = lp(elR, -6f, wOp)
                }
            } else if (tkSpin) {
                rxL = lp(rxL, -172f, wBd); rzL = lp(rzL, -6f, wBd); elL = lp(elL, -6f, wBd)
                if (!toolArm) { rxR = lp(rxR, -172f, wBd); rzR = lp(rzR, 6f, wBd); elR = lp(elR, -6f, wBd) }
            } else if (tkSuper) {
                rxL = lp(rxL, -166f, wBd); rzL = lp(rzL, -7f, wBd); elL = lp(elL, -3f, wBd)
                if (!toolArm) { rxR = lp(rxR, -166f, wBd); rzR = lp(rzR, 7f, wBd); elR = lp(elR, -3f, wBd) }
            } else {
                rxL = lp(rxL, 0f, wBd); rzL = lp(rzL, -80f, wBd); elL = lp(elL, -4f, wBd)
                if (!toolArm) { rxR = lp(rxR, 0f, wBd); rzR = lp(rzR, 80f, wBd); elR = lp(elR, -4f, wBd) }
            }
        }
        if (tuck > 0.001f) {   // dash aéreo carregando: braços fechados na frente do corpo, em guarda
            val k = min(1f, tuck * 3f)
            rxL = lp(rxL, -40f - 20f * tuck, k); rzL = lp(rzL, -(10f + 6f * tuck), k); elL = lp(elL, -(60f + 20f * tuck), k)
            if (!toolArm) { rxR = lp(rxR, -40f - 20f * tuck, k); rzR = lp(rzR, 10f + 6f * tuck, k); elR = lp(elR, -(60f + 20f * tuck), k) }
        }
        if (lwE > 0.001f) {   // decolagem: os dois braços sobem acima da cabeça e vão relaxando
            rxL = lp(rxL, -168f, lwE); rzL = lp(rzL, -10f, lwE); elL = lp(elL, -4f, lwE)
            if (!toolArm) { rxR = lp(rxR, -168f, lwE); rzR = lp(rzR, 10f, lwE); elR = lp(elR, -4f, lwE) }
        }
        var dashToolA = 0f
        if (dashW > 0.001f && fl > 0.01f) {   // voo rápido: braços pra trás, rentes ao corpo (puxa mais no impulso)
            val dwA = dashW * (1f - min(1f, tkw * 2.5f))   // durante a manobra a pose dela manda
            val ax = lp(14f, 36f, wind); val fl2 = sin(t * 9f) * 3f
            rxL = lp(rxL, ax + fl2, dwA); rxR = lp(rxR, ax - fl2, dwA)
            rzL = lp(rzL, -9f, dwA); rzR = lp(rzR, 9f, dwA); elL = lp(elL, -5f, dwA); elR = lp(elR, -5f, dwA)
            dashToolA = dwA * (-lean + 180f - (rxR + elR))   // item fica pra trás, longe da cabeça
        }
        an.armFwdR = 0f
        an.toolA = if (swimming) swimToolA else dashToolA
        if (land > 0f) { rzL -= 25f * land; if (!toolArm) rzR += 25f * land }
        var elbowSpin = 0f
        if (li > 0.001f) {   // rastejar: cada braço alcança pra frente no plano do chão (levantado), apoia e puxa com o cotovelo dobrado no plano
            val mc = min(1f, mv * 3f); val pl = (0.5f + 0.5f * sin(ph)) * mc; val pr = (0.5f + 0.5f * sin(ph + 3.1416f)) * mc
            val fwdL = max(0f, cos(ph)) * mc; val fwdR = max(0f, cos(ph + 3.1416f)) * mc
            rxL = lp(rxL, 3f + 17f * fwdL, li); rxR = lp(rxR, 3f + 17f * fwdR, li)
            rzL = lp(rzL, -(32f + 68f * pl), li); rzR = lp(rzR, 32f + 68f * pr, li)
            elL = lp(elL, -(14f + 36f * (1f - pl)), li); elR = lp(elR, -(14f + 36f * (1f - pr)), li)
            ryR = lp(ryR, 0f, li); ryL = lp(ryL, 0f, li); elbowSpin = 90f * li
        }
        if (skw > 0.001f) {   // braços de skatista: abertos pro equilíbrio, balançam no empurrão, sobem no ollie, um pega a prancha no grab
            val kPop = an.skPop.coerceIn(0f, 1f); val kLand = an.skLand.coerceIn(0f, 1f); val kGr = an.skGrab.coerceIn(0f, 1f)
            val kMan = an.skMan.coerceIn(0f, 1f); val kGd = an.skGrind.coerceIn(0f, 1f); val kFl = an.skFlip.coerceIn(0f, 1f); val kPw = an.skPush.coerceIn(0f, 1f)
            val w1 = sin(an.t * 0.9f); val w2 = sin(an.t * 0.9f + 0.35f)
            var lx = -7f; var rx2 = -7f; var lz = 58f + 2f * w1; var rz2 = 58f + 2f * w2; var lel = -13f; var rel = -13f
            if (kPw > 0.001f) {
                // Contrapeso curto e controlado: tronco estável, sem braços chicoteando.
                val c = sin(an.skPushPh * 6.2832f)
                lx = lp(lx, -9f + 7f * c, kPw)
                rx2 = lp(rx2, -9f - 7f * c, kPw)
                lel = lp(lel, -12f + 3f * c, kPw)
                rel = lp(rel, -12f - 3f * c, kPw)
                lz = lp(lz, 62f + 4f * c, kPw)
                rz2 = lp(rz2, 62f - 4f * c, kPw)
            }
            lz = lp(lz, 118f, kPop); rz2 = lp(rz2, 118f, kPop); lel = lp(lel, -6f, kPop); rel = lp(rel, -6f, kPop)
            lz = lp(lz, 74f, kLand * 0.8f); rz2 = lp(rz2, 74f, kLand * 0.8f)
            lz = lp(lz, 84f, kMan); rz2 = lp(rz2, 84f, kMan)
            lz = lp(lz, 62f + 38f * an.skBal, kGd); rz2 = lp(rz2, 62f - 38f * an.skBal, kGd)
            lz = lp(lz, 80f, kFl); rz2 = lp(rz2, 80f, kFl)
            if (kGr > 0.001f) {
                val gk = an.skGrabK.toInt()
                val frontHand = gk == 2 || gk == 3 || gk == 4
                val gz = when (gk) { 4, 5 -> 40f; 2 -> 16f; 3 -> 8f; else -> 6f }
                if (frontHand) { lx = lp(lx, -20f, kGr); lz = lp(lz, gz, kGr); lel = lp(lel, -22f, kGr); rz2 = lp(rz2, 108f, kGr); rx2 = lp(rx2, 4f, kGr) }
                else { rx2 = lp(rx2, -20f, kGr); rz2 = lp(rz2, gz, kGr); rel = lp(rel, -22f, kGr); lz = lp(lz, 108f, kGr); lx = lp(lx, 4f, kGr) }
            }
            rxL = lp(rxL, lx, skw); rxR = lp(rxR, rx2, skw); rzL = lp(rzL, -lz, skw); rzR = lp(rzR, rz2, skw)
            elL = lp(elL, lel, skw); elR = lp(elR, rel, skw); ryL = lp(ryL, 0f, skw); ryR = lp(ryR, 0f, skw)
        }
        val rd = an.ride.coerceIn(0f, 1f)
        if (rd > 0.001f) { rxL = lp(rxL, -62f, rd); rxR = lp(rxR, -62f, rd); elL = lp(elL, -14f, rd); elR = lp(elR, -14f, rd); rzL = lp(rzL, -5f, rd); rzR = lp(rzR, 5f, rd) }

        // ================= ajudantes: tudo em PIXELS do Minecraft, relativo ao centro de cada parte =================
        fun hb(x: Float, y: Float, z: Float, w: Float, h: Float, d: Float, col: Int, a: Float = 1f, rx: Float = 0f, ry: Float = 0f, rz: Float = 0f) =
            bx(hm, x * U, 4f * U + y * U, z * U, rx, ry, w * U, h * U, d * U, 0f, col, a, rz)          // cabeça (centro da cabeça)
        fun tb(x: Float, y: Float, z: Float, w: Float, h: Float, d: Float, col: Int, a: Float = 1f, rx: Float = 0f, ry: Float = 0f, rz: Float = 0f) =
            bx(bm, x * U, (18f + y) * U, z * U, rx, ry, w * U, h * U, d * U, 0f, col, a, rz)            // tronco (centro do tronco)
        var kbend = 0f; var curLeg: FloatArray? = null; val lkM = FloatArray(16)   // joelho de verdade (só no voo): caixas da perna abaixo do meio giram junto com a canela
        fun lb(m: FloatArray, x: Float, y: Float, z: Float, w: Float, h: Float, d: Float, col: Int) {   // perna (centro da perna)
            if (kbend > 0.5f && m === curLeg) {
                val tp = y + h / 2f; val bt = y - h / 2f
                if (bt >= 0f) bx(m, x * U, (-6f + y) * U, z * U, 0f, 0f, w * U, h * U, d * U, 0f, col, 1f, 0f)
                else if (tp <= 0f) bx(lkM, x * U, y * U, z * U, 0f, 0f, w * U, h * U, d * U, 0f, col, 1f, 0f)
                else {
                    bx(m, x * U, (-6f + tp / 2f) * U, z * U, 0f, 0f, w * U, tp * U, d * U, 0f, col, 1f, 0f)
                    bx(lkM, x * U, (bt / 2f) * U, z * U, 0f, 0f, w * U, -bt * U, d * U, 0f, col, 1f, 0f)
                }
            } else bx(m, x * U, (-6f + y) * U, z * U, 0f, 0f, w * U, h * U, d * U, 0f, col, 1f, 0f)
        }
        fun ab(m: FloatArray, x: Float, y: Float, z: Float, w: Float, h: Float, d: Float, col: Int) =
            bx(m, x * U, (-4f + y) * U, z * U, 0f, 0f, w * U, h * U, d * U, 0f, col, 1f, 0f)             // braço (centro do braço)

        val hairC = Look.hair(); val hairD = shadeC(hairC, 0.8f); val hairL = lite(hairC, 0.25f)
        val eyeC = Look.EYE_COLORS[L[Look.EYEC].coerceIn(0, Look.EYE_COLORS.size - 1)]
        val shoeC = Look.pal(Look.SHOEC); val hatC = Look.pal(Look.HATC); val backC = Look.pal(Look.BACKC); val neckC = Look.pal(Look.NECKC)
        val leather = 0x6B4A2A; val steel = 0xC5CEDA
        val aw = if (girl) 3f else 4f   // Alex (menina): braços de 3 px
        // Slots de acabamento expostos na interface aplicados ao personagem renderizado no jogo.
        val accentTop = Look.pal(Look.TOP_ACCENT)
        val accentBottom = Look.pal(Look.BOTTOM_ACCENT)
        val accentHair = Look.pal(Look.HAIR_ACCENT_COLOR)
        val topPattern = L[Look.TOP_PATTERN].coerceIn(0, Look.TOP_PATTERNS.size - 1)
        val bottomPattern = L[Look.BOTTOM_PATTERN].coerceIn(0, Look.BOTTOM_PATTERNS.size - 1)
        val hairAccentStyle = L[Look.HAIR_ACCENT].coerceIn(0, Look.HAIR_ACCENTS.size - 1)
        val metalHi = lite(steel, 0.34f)


        // ================= PERNAS =================
        val pantPx = when { overalls -> 12f; full -> 0f; else -> when (bot) { 0 -> 12f; 1 -> 5f; 3 -> 8.5f; 4 -> 12f; 6 -> 12f; 7 -> 12f; else -> 0f } }
        val pantC = if (overalls) tc else if (bot == 6) shadeC(bc, 0.78f) else bc
        val pantW = if (bot == 4 && !full && !overalls) 6.4f else 4.6f
        var skirtLen = 0f; var skirtC = bc; var hemC = lite(bc, 0.35f)
        if (full) { skirtLen = when (top) { 2 -> 8.5f; 10 -> 11f; 11 -> 11.5f; else -> 8f }; skirtC = if (top == 15) shadeC(tc, 0.4f) else tc; hemC = if (top == 11) gold else if (top == 15) white else lite(tc, 0.4f) }
        else if (!overalls && (bot == 2 || bot == 5)) { skirtLen = if (bot == 2) 6f else 6.5f; skirtC = bc }
        else if (top == 4 && !overalls) { skirtLen = 3.5f; skirtC = tc; hemC = lite(tc, 0.4f) }
        else if (top == 17) { skirtLen = 8f; skirtC = tc; hemC = shadeC(tc, 0.7f) }
        val shoe = L[Look.SHOES]
        // a perna base já é pintada com a cor da roupa/sapato onde elas cobrem: se a perna girar e abrir uma fresta (quadril, entre as pernas, pé),
        // aparece tecido e não pele
        val covTop = if (pantPx > 0f) pantPx else skirtLen
        val covC = if (pantPx > 0f) pantC else shadeC(skirtC, 0.7f)
        val shoeH = when (shoe) { 0 -> 4f; 1 -> 2.4f; 4 -> 8f; 5 -> 2f; 6 -> 2f; 7 -> 6f; else -> 0f }
        for (sd in intArrayOf(-1, 1)) {
            val s = sd.toFloat(); val li2 = if (sd < 0) 0 else 1
            val hip = if (sd < 0) hipL else hipR; val kn = if (sd < 0) kneeL else kneeR
            val kr = max(max(max(fl, tkw), rw), skw)
            var ang = lp(hip - kn * 0.4f, hip, kr)   // perna rígida (sem joelho): o joelho só puxa um pouco o ângulo; no voo o joelho dobra de verdade (kbend)
            if (cr > 0f) ang = lp(ang, (if (sd < 0) 1f else -1f) * sw * 0.4f - 4f, cr)   // agachar do Minecraft: pernas quase retas, tronco inclinado
            if (jch > 0f) ang = lp(ang, -6f * jch, min(1f, jch * 3f))   // carregando: joelhos um pouco à frente
            if (bt > 0f) ang = lp(ang, -62f, bt)   // moto: pernas dobradas nas pedaleiras
            // pernas um pouco abertas no voo parado (abre pro lado em relação ao eixo da perna, que acompanha a inclinação do corpo)
            val splay = if (fl > 0.01f) (fl * (1f - dashW) * (9f * (1f - fm) + 2f * fm + 8f * fd - 7f * fu + sin(t * 1.7f + 1f) * 1.5f * (1f - fm)) * (1f - max(tuck, dst))).coerceAtLeast(0f) else 0f
            val legT = (ang + lean * fl) * 0.017453f
            // Com o tronco frontal, os pés ficam escalonados: apoio na prancha e pé traseiro fora dela.
            val hipX = lp(s * 2f * U, if (sd < 0) -0.16f else 0f, pushFace)
            val hipZ = (if (sd < 0) -0.13f else 0.13f) * pushFace
            piv(legM[li2], r2, hipX, hipY, hipZ, rx = ang + lean * fl, ry = -s * splay * sin(legT), rz = s * (5f + 7f * (if (sd < 0) qLegL else qLegR)) * li + s * splay * cos(legT) + s * (if (sd < 0) spR else spF))
            if (legSq > 0f) Matrix.scaleM(legM[li2], 0, 1f + 0.4f * legSq, 1f - legSq, 1f + 0.4f * legSq)   // perna amassa e alarga
            val lm = legM[li2]
            kbend = if (kr > 0.01f) max(0f, kn) * kr else 0f; curLeg = lm
            if (kbend > 0.5f) piv(lkM, lm, 0f, -6f * U, 0f, rx = kbend)
            lay(0, 0)
            var topH = min(covTop, 12f); val botH = shoeH
            if (topH + botH > 12f) topH = 12f - botH
            val midH = 12f - topH - botH
            if (topH > 0.01f) lb(lm, 0f, 6f - topH / 2f, 0f, 4f, topH, 4f, covC)
            if (midH > 0.01f) lb(lm, 0f, 6f - topH - midH / 2f, 0f, 4f, midH, 4f, skin)
            if (botH > 0.01f) lb(lm, 0f, -6f + botH / 2f, 0f, 4f, botH, 4f, shoeC)
            lay(1, 5)
            if (pantPx > 0f) {
                lb(lm, 0f, 6f - pantPx / 2f, 0f, pantW, pantPx, pantW, pantC)
                if (pantPx >= 8f) lb(lm, 0f, 6f - pantPx + 0.5f, 0f, pantW + 0.2f, 1f, pantW + 0.2f, shadeC(pantC, 0.8f))
                if (bot == 7 && !full && !overalls) lb(lm, s * 2.45f, 1.5f, 0.3f, 0.7f, 3.4f, 2.8f, shadeC(pantC, 0.85f))
                if (bot == 1) lb(lm, 0f, 6f - 5f + 0.4f, 0f, 4.8f, 0.8f, 4.8f, lite(pantC, 0.25f))
            }
            if (skirtLen > 0f) {
                lb(lm, 0f, 6f - skirtLen / 2f, 0f, 5.1f, skirtLen, 5.3f, skirtC)
                lb(lm, 0f, 6f - skirtLen + 0.4f, 0f, 5.3f, 0.8f, 5.5f, hemC)
                if (bot == 5 && !full) lb(lm, 0.9f, 6f - skirtLen / 2f, 2.7f, 0.7f, skirtLen - 1f, 0.3f, shadeC(skirtC, 0.78f))
            }
            when (shoe) {
                0 -> { lb(lm, 0f, -4f, 0f, 4.7f, 4f, 4.7f, shoeC); lb(lm, 0f, -5f, 0.9f, 4.3f, 2f, 5.4f, shoeC); lb(lm, 0f, -2.2f, 0f, 5f, 0.8f, 5f, lite(shoeC, 0.3f)) }
                1 -> { lb(lm, 0f, -5.6f, 0.4f, 4.9f, 0.8f, 5.5f, white); lb(lm, 0f, -4.4f, 0.35f, 4.6f, 2.4f, 5.2f, shoeC); lb(lm, 0f, -3.3f, 0.9f, 3f, 0.4f, 1.4f, white) }
                2 -> { lb(lm, 0f, -5.3f, 0.3f, 4.5f, 1.4f, 5.1f, shoeC); lb(lm, 0f, -4.6f, 1.6f, 1.2f, 0.7f, 0.5f, lite(shoeC, 0.4f)) }
                4 -> { lb(lm, 0f, -2f, 0f, 4.7f, 8f, 4.7f, shoeC); lb(lm, 0f, -5f, 0.9f, 4.3f, 2f, 5.4f, shoeC); lb(lm, 0f, 1.8f, 0f, 5f, 0.8f, 5f, lite(shoeC, 0.3f)) }
                5 -> { lb(lm, 0f, -5.4f, 1.6f, 4.8f, 1.2f, 1.2f, 0x8A5A3A); lb(lm, 0f, -5.4f, -1.6f, 4.8f, 1.2f, 1.2f, 0x8A5A3A); lb(lm, 0f, -4.3f, 0.2f, 4.8f, 0.8f, 5.2f, 0xC8935A); lb(lm, 0f, -3.6f, 0.9f, 4.3f, 0.7f, 1.2f, shoeC) }
                6 -> { lb(lm, 0f, -5.4f, 0.3f, 4.7f, 1.2f, 5.3f, lite(shoeC, 0.2f)); lb(lm, 0f, -4.3f, 0.3f, 4.6f, 1.6f, 5.1f, shoeC) }
                7 -> { for (k in 0..5) lb(lm, 0f, -5.5f + k.toFloat(), 0f, 4.6f, 1f, 4.6f, if (k % 2 == 0) shoeC else white); lb(lm, 0f, -5.7f, 0.5f, 4.7f, 0.7f, 5.4f, shadeC(shoeC, 0.6f)) }
            }


            // Material pixelado de pantalones: sombra de costura, desgaste y reflejos por tipo de tecido.
            val pantY=6f-max(0.4f,pantPx)/2f
            if(pantPx>1f) {
                val legFront=if(pantW>5f) 3.28f else 2.42f
                val legShade=shadeC(pantC,0.72f)
                val legLight=lite(pantC,0.16f)
                lb(lm,-1.72f, pantY, legFront,0.12f,max(0.8f,pantPx-0.6f),0.06f,legShade)
                lb(lm,1.72f, pantY, legFront,0.12f,max(0.8f,pantPx-0.6f),0.06f,legLight)
                for(row in 0..4) {
                    val yy=6f-1.3f-row*1.65f
                    if(yy>6f-pantPx+0.4f && yy<5.8f) {
                        val xx=if((row+sd)%2==0) -0.9f else 0.9f
                        val cc=when((row+bot)%4) { 0 -> legShade; 1 -> legLight; 2 -> shadeC(accentBottom,0.82f); else -> pantC }
                        if(bot==0 || bot==4 || bot==7 || row%2==0)
                            lb(lm,xx,yy,legFront+0.07f,0.48f,0.48f,0.06f,cc)
                    }
                }
                if(bot==4 || bot==7) {
                    val pocketY=6f-min(pantPx*0.36f,4f)
                    lb(lm,s*1.15f,pocketY,legFront+0.1f,1.1f,1.4f,0.08f,legShade)
                    lb(lm,s*1.15f,pocketY+0.42f,legFront+0.16f,0.78f,0.16f,0.06f,accentBottom)
                }
            }
            lay(5,10)
            if(pantPx>1f) {
                lb(lm,s*2.18f,pantY,0f,0.24f,max(0.6f,pantPx-0.25f),4.72f,shadeC(pantC,0.7f))
                lb(lm,s*1.68f,pantY,2.18f,0.08f,max(0.6f,pantPx-0.5f),0.08f,lite(pantC,0.25f))
                val py=6f-min(pantPx*0.34f,3.2f)
                if(bot==0 || bot==3 || bot==6) { lb(lm,-1.1f,py,2.3f,1.1f,1f,0.12f,shadeC(pantC,0.75f)); lb(lm,-1.1f,py+0.38f,2.4f,1.1f,0.16f,0.08f,lite(pantC,0.18f)); lb(lm,-1.1f,py+0.38f,2.46f,0.18f,0.18f,0.06f,accentBottom) }
                when(bottomPattern) {
                    1 -> lb(lm,s*2.25f,pantY,0f,0.42f,max(0.6f,pantPx-0.2f),4.85f,accentBottom)
                    2 -> { lb(lm,0.9f,py,2.34f,1.15f,1.05f,0.14f,accentBottom); lb(lm,0.9f,py+0.4f,2.43f,1.1f,0.16f,0.08f,lite(accentBottom,0.3f)) }
                    3 -> { val ky=6f-min(pantPx-0.2f,7f); lb(lm,0f,ky,2.35f,3.3f,1.25f,0.18f,shadeC(accentBottom,0.6f)); lb(lm,0f,ky,2.46f,2.75f,0.86f,0.08f,accentBottom); for(x in intArrayOf(-1,1)) lb(lm,x.toFloat(),ky,2.52f,0.1f,0.7f,0.06f,metalHi) }
                    4 -> { val cy=6f-min(pantPx*0.46f,4.8f); lb(lm,s*1.1f,cy,2.3f,1.55f,2f,0.16f,shadeC(pantC,0.68f)); lb(lm,s*1.1f,cy+0.45f,2.4f,1.3f,0.16f,0.08f,accentBottom) }
                    5 -> for(y in intArrayOf(6,3,0,-3)) if(y>6-pantPx && y<6) lb(lm,0f,y.toFloat(),2.34f,4.1f,0.2f,0.08f,accentBottom)
                    6 -> for(y in intArrayOf(4,1,-2)) if(y>6-pantPx && y<6) { lb(lm,0f,y.toFloat(),2.36f,0.72f,0.72f,0.1f,shadeC(accentBottom,0.65f)); lb(lm,0f,y.toFloat(),2.44f,0.36f,0.36f,0.08f,lite(accentBottom,0.3f)) }
                }
            }
            if(skirtLen>0.5f) {
                for(x in intArrayOf(-2,0,2)) lb(lm,x.toFloat(),6f-skirtLen/2f,2.72f,0.12f,max(1f,skirtLen-0.8f),0.08f,if(x==0) lite(skirtC,0.28f) else shadeC(skirtC,0.72f))
                when(bottomPattern) {
                    1,5 -> for(y in intArrayOf(-2,0)) lb(lm,0f,6f-skirtLen+y*0.25f,2.76f,5f,0.16f,0.08f,accentBottom)
                    2,6 -> for(x in intArrayOf(-1,1)) lb(lm,x*1.2f,6f-skirtLen/2f,2.78f,0.42f,0.62f,0.08f,accentBottom)
                    3 -> lb(lm,0f,6f-min(skirtLen-0.7f,2.4f),2.79f,4.2f,0.9f,0.1f,accentBottom)
                    4 -> for(x in intArrayOf(-1,1)) lb(lm,x*1.4f,6f-skirtLen/2f,2.78f,0.6f,1.5f,0.1f,accentBottom)
                }
            }
            // Solado em duas camadas, costura das botas, ilhoses/cadarços dos tênis.
            if(shoe!=3) {
                lb(lm,0f,-5.85f,0.45f,4.9f,0.52f,5.6f,shadeC(shoeC,0.58f))
                lb(lm,0f,-5.56f,0.65f,4.65f,0.16f,5.35f,lite(shoeC,0.24f))
                when(shoe) {
                    0,4 -> { val rows=if(shoe==4) intArrayOf(1,-1,-3) else intArrayOf(-1,-3); for(y in rows) lb(lm,0f,y.toFloat(),2.56f,4.2f,0.16f,0.1f,shadeC(shoeC,0.62f)); for(x in intArrayOf(-1,1)) lb(lm,x*1.7f,-2.2f,2.64f,0.24f,0.38f,0.1f,metalHi) }
                    1 -> { for(k in 0..3) lb(lm,-0.55f+k*0.36f,-4f+(k%2)*0.28f,3f,0.9f,0.15f,0.08f,white); lb(lm,0f,-3f,3f,2.5f,0.18f,0.08f,white) }
                    2,6 -> { lb(lm,0f,-4.35f,2.85f,2.1f,0.18f,0.08f,metalHi); for(x in intArrayOf(-1,1)) lb(lm,x*1.55f,-4.65f,2.85f,0.18f,0.18f,0.08f,accentBottom) }
                    5 -> lb(lm,0f,-4.1f,1f,4.1f,0.18f,0.16f,0xE5BE78)
                    7 -> for(k in 0..5) lb(lm,0f,-5.3f+k*0.78f,2.55f,4.15f,0.12f,0.08f,if(k%2==0) accentBottom else white)
                }
            } else {
                lb(lm,0f,-5.25f,0.85f,4.6f,1.25f,5.8f,skin)
                for(x in intArrayOf(-2,-1,0,1,2)) lb(lm,x*0.75f,-5.55f,2.7f,0.48f,0.45f,0.6f,skin)
            }
            if (kbend > 2f) {   // junta do joelho: tampa a fresta que abre ao dobrar
                lay(1, 5)
                val jw = if (pantPx >= 6f) pantW + 0.05f else 4.04f
                bx(lkM, 0f, 0f, 0f, 0f, 0f, jw * U, 2.2f * U, jw * U, 0f, if (pantPx >= 6f) pantC else skin, 1f, 0f)
            }
            kbend = 0f; curLeg = null
        }

        // quadril: um bloco por baixo do tronco (cor da roupa de baixo) que tapa a fresta que se abre quando as pernas balançam
        lay(0, 0)
        tb(0f, -7f, 0f, 7.9f, 2.8f, 3.9f, covC)

        // ================= TRONCO + ROUPA (pixel-art por face, estilo skin de Minecraft) =================
        lay(0, 0)
        tb(0f, 0f, 0f, 8f, 12f, 4f, skin)
        val spec = ClothData.top(top)
        val cp = ClothArt.pal(tc, accentTop, skin)
        val sleeve = spec.sleeve.toFloat()
        val tCol = cp[spec.baseT.code]; val sCol = cp[spec.baseS.code]
        lay(1, 1)
        tb(0f, 0f, 0f, 8.7f, 12.2f, 4.7f, tCol)
        run {
            lay(2, 2)
            val cw = 8.7f / 8f; val chh = 12.2f / 12f; val dz = 4.7f / 4f; val th = 0.14f; val off = 2.35f + 0.05f
            ClothArt.greedy(ClothArt.withPattern(ClothArt.rows(spec.front), topPattern), spec.baseT) { x0, y0, w, h, c ->
                tb(-4.35f + (x0 + w / 2f) * cw, 6.1f - (y0 + h / 2f) * chh, off, w * cw, h * chh, th, cp[c.code]) }
            ClothArt.greedy(ClothArt.rows(spec.back), spec.baseT) { x0, y0, w, h, c ->
                tb(4.35f - (x0 + w / 2f) * cw, 6.1f - (y0 + h / 2f) * chh, -off, w * cw, h * chh, th, cp[c.code]) }
            val sideRows = ClothArt.rows(spec.side)
            for (sd in intArrayOf(-1, 1)) ClothArt.greedy(sideRows, spec.baseT) { x0, y0, w, h, c ->
                tb(sd * (4.35f + 0.05f), 6.1f - (y0 + h / 2f) * chh, 2.35f - (x0 + w / 2f) * dz, th, h * chh, w * dz, cp[c.code]) }
        }

        // ================= BRAÇOS =================
        val armFr = ClothArt.rows(spec.armF).let { if (girl) ClothArt.slim(it) else it }
        val armBk = ClothArt.rows(spec.armB).let { if (girl) ClothArt.slim(it) else it }
        val armOu = ClothArt.rows(spec.armO)
        for (sd in intArrayOf(-1, 1)) {
            val s = sd.toFloat(); val ai = if (sd < 0) 0 else 1
            val rx = if (sd < 0) rxR else rxL; val rz = if (sd < 0) -rzR else -rzL; val el = if (sd < 0) elR else elL   // +x é a ESQUERDA do boneco: o item vai na direita (sd<0)
            val ry = if (sd < 0) ryR else ryL
            piv(armM[ai], bm, s * (4f + aw / 2f) * U, 22f * U, 0f, rx = rx + el * 0.55f, ry = ry, rz = rz)
            val am = armM[ai]
            lay(0, 0)
            val slvH = min(sleeve, 12f)
            if (slvH > 0.01f) ab(am, 0f, 6f - slvH / 2f, 0f, aw, slvH, 4f, sCol)
            if (12f - slvH > 0.01f) ab(am, 0f, -6f + (12f - slvH) / 2f, 0f, aw, 12f - slvH, 4f, skin)
            lay(1, 5)
            if (sleeve > 0f) ab(am, 0f, 6f - sleeve / 2f, 0f, aw + 0.7f, sleeve, 4.7f, sCol)
            // mangas largas, ombreiras, babados: formas extras com desenho próprio
            for (e in spec.ex) ab(am, s * e.cx, e.cy, 0f, aw + e.we, e.h, e.d, cp[e.base.code])
            lay(6, 6)
            if (sleeve > 0f) {
                val wA = aw + 0.7f; val cwA = wA / aw; val dz = 4.7f / 4f; val th = 0.14f; val off = 2.35f + 0.05f
                // frente/costas: colunas "de fora pra dentro" (0 = borda de fora)
                ClothArt.greedy(armFr, spec.baseS) { x0, y0, w, h, c ->
                    ab(am, s * (wA / 2f - (x0 + w / 2f) * cwA), 6f - (y0 + h / 2f), off, w * cwA, h.toFloat(), th, cp[c.code]) }
                ClothArt.greedy(armBk, spec.baseS) { x0, y0, w, h, c ->
                    ab(am, s * (wA / 2f - (x0 + w / 2f) * cwA), 6f - (y0 + h / 2f), -off, w * cwA, h.toFloat(), th, cp[c.code]) }
                ClothArt.greedy(armOu, spec.baseS) { x0, y0, w, h, c ->
                    ab(am, s * (wA / 2f + 0.05f), 6f - (y0 + h / 2f), 2.35f - (x0 + w / 2f) * dz, th, h.toFloat(), w * dz, cp[c.code]) }
            }
            for (e in spec.ex) {
                val wE = aw + e.we; val th = 0.14f; val ex0 = s * e.cx
                val fr = ClothArt.rows(e.front); val bk = ClothArt.rows(e.back); val ou = ClothArt.rows(e.outer)
                val cwE = wE / fr[0].length; val chE = e.h / fr.size; val dzE = e.d / ou[0].length; val chO = e.h / ou.size
                ClothArt.greedy(fr, e.base) { x0, y0, w, h, c ->
                    ab(am, ex0 - wE / 2f + (x0 + w / 2f) * cwE, e.cy + e.h / 2f - (y0 + h / 2f) * chE, e.d / 2f + 0.05f, w * cwE, h * chE, th, cp[c.code]) }
                ClothArt.greedy(bk, e.base) { x0, y0, w, h, c ->
                    ab(am, ex0 + wE / 2f - (x0 + w / 2f) * cwE, e.cy + e.h / 2f - (y0 + h / 2f) * chE, -(e.d / 2f + 0.05f), w * cwE, h * chE, th, cp[c.code]) }
                ClothArt.greedy(ou, e.base) { x0, y0, w, h, c ->
                    ab(am, ex0 + s * (wE / 2f + 0.05f), e.cy + e.h / 2f - (y0 + h / 2f) * chO, e.d / 2f - (x0 + w / 2f) * dzE, th, h * chO, w * dzE, cp[c.code]) }
            }
            if (sd < 0 && handOut != null) {
                System.arraycopy(am, 0, handOut, 0, 16)
                Matrix.translateM(handOut, 0, 0f, -0.50f, 0.02f)
            }
        }

        // ================= CABEÇA: rosto =================
        lay(0, 0)
        hb(0f, 0f, 0f, 8f, 8f, 8f, skin)
        lay(1, 7)
        hb(0f, -1.5f, 4.06f, 1f, 1f, 0.2f, shadeC(skin, 0.9f))   // nariz
        val ez = 4.1f
        val eyeY = -0.5f
        val lid = shadeC(skin, 0.55f)
        val es = L[Look.EYES]

        // Olhos desenhados como pixels de skin: contorno, branco, íris, pupila e reflexos.
        for (sg in intArrayOf(-1, 1)) {
            val g = sg.toFloat()
            val ex = g * 2f
            if (blink && es != 2) {
                hb(ex, eyeY-0.1f, ez+0.05f, 2.35f, 0.28f, 0.22f, lid)
                hb(ex, eyeY+0.08f, ez+0.08f, 2.15f, 0.12f, 0.08f, shadeC(hairC,0.58f))
                continue
            }
            when(es) {
                1 -> { // olhos sorridentes, com cílios em pixels
                    hb(ex,eyeY+0.05f,ez,2.35f,0.34f,0.2f,0x29202A,rz=g*10f)
                    hb(ex,eyeY-0.08f,ez+0.05f,1.45f,0.16f,0.08f,eyeC)
                    for(k in intArrayOf(-1,1)) hb(ex+k*0.75f,eyeY+0.18f,ez+0.08f,0.3f,0.28f,0.08f,0x29202A,rz=g*k*12f)
                }
                2 -> { // olhos pequenos e limpos
                    hb(ex,eyeY-0.02f,ez,1.05f,1.05f,0.2f,0x29202A)
                    hb(ex-0.12f,eyeY+0.1f,ez+0.08f,0.25f,0.25f,0.06f,white)
                }
                3,8 -> { // sonolentos/cansados, pálpebra cobre a parte superior
                    hb(ex,eyeY-0.15f,ez,2.15f,1.75f,0.2f,0x2A202A)
                    hb(ex,eyeY-0.35f,ez+0.05f,1.55f,1.05f,0.08f,eyeC)
                    hb(ex,eyeY+0.38f,ez+0.1f,2.3f,0.48f,0.12f,lid,rz=g*5f)
                    hb(ex,eyeY-0.82f,ez+0.08f,1.25f,0.12f,0.06f,lite(skin,0.12f))
                    hb(ex-0.25f,eyeY-0.12f,ez+0.12f,0.28f,0.28f,0.06f,white)
                }
                5 -> { // olhar sério e anguloso
                    hb(ex,eyeY-0.08f,ez,2.25f,1.75f,0.2f,0x29202A)
                    hb(ex,eyeY-0.18f,ez+0.05f,1.65f,1.2f,0.08f,eyeC)
                    hb(ex,eyeY-0.28f,ez+0.1f,0.68f,1.05f,0.06f,0x1A1620)
                    hb(ex-g*0.12f,eyeY+0.68f,ez+0.12f,2.55f,0.34f,0.1f,shadeC(hairC,0.58f),rz=g*13f)
                    hb(ex-0.3f,eyeY+0.12f,ez+0.14f,0.28f,0.25f,0.05f,white)
                }
                6 -> { // estrela em pixels no centro da íris
                    hb(ex,eyeY-0.05f,ez,2.3f,2.45f,0.2f,0x29202A)
                    hb(ex,eyeY-0.1f,ez+0.05f,1.85f,2.05f,0.08f,eyeC)
                    hb(ex,eyeY-0.1f,ez+0.1f,0.35f,1.5f,0.06f,0xFFF1A0)
                    hb(ex,eyeY-0.1f,ez+0.1f,1.25f,0.35f,0.06f,0xFFF1A0)
                    hb(ex-0.35f,eyeY+0.45f,ez+0.13f,0.35f,0.35f,0.05f,white)
                }
                7 -> { // pupila felina vertical
                    hb(ex,eyeY-0.08f,ez,2.2f,2.45f,0.2f,0x29202A)
                    hb(ex,eyeY-0.12f,ez+0.05f,1.72f,2.08f,0.08f,eyeC)
                    hb(ex,eyeY-0.12f,ez+0.1f,0.38f,1.72f,0.06f,0x17131D)
                    hb(ex-0.3f,eyeY+0.48f,ez+0.13f,0.35f,0.35f,0.05f,white)
                    hb(ex+0.3f,eyeY-0.55f,ez+0.13f,0.18f,0.18f,0.05f,lite(eyeC,0.42f))
                }
                else -> { // grandes/brilhantes: estética anime pixelada
                    hb(ex,eyeY-0.05f,ez,2.45f,2.65f,0.22f,0x29202A)
                    hb(ex,eyeY-0.08f,ez+0.04f,2.05f,2.35f,0.1f,white)
                    hb(ex,eyeY-0.16f,ez+0.09f,1.55f,2.0f,0.08f,eyeC)
                    hb(ex,eyeY-0.35f,ez+0.13f,0.75f,1.35f,0.06f,0x17131D)
                    hb(ex-0.35f,eyeY+0.43f,ez+0.16f,0.48f,0.48f,0.05f,white)
                    hb(ex+0.34f,eyeY-0.52f,ez+0.16f,0.22f,0.22f,0.05f,lite(eyeC,0.55f))
                    hb(ex,eyeY+1.16f,ez+0.12f,2.5f,0.3f,0.1f,0x29202A,rz=g*5f)
                    if(es==4) {
                        hb(ex-0.25f,eyeY+0.15f,ez+0.17f,0.3f,0.62f,0.04f,white)
                        hb(ex+0.22f,eyeY-0.48f,ez+0.17f,0.26f,0.5f,0.04f,white)
                    }
                }
            }
        }
        val mouthC = mixC(skin, 0x8A2A2A, 0.65f)
        when (L[Look.MOUTH]) {
            0 -> { hb(0f, -2.7f, ez, 2f, 0.7f, 0.25f, mouthC); hb(-1.4f, -2.3f, ez, 0.7f, 0.6f, 0.25f, mouthC); hb(1.4f, -2.3f, ez, 0.7f, 0.6f, 0.25f, mouthC) }
            1 -> hb(0f, -2.6f, ez, 2.4f, 0.7f, 0.25f, mouthC)
            2 -> hb(0f, -2.6f, ez, 1f, 1f, 0.25f, mixC(skin, 0xD05060, 0.7f))
            3 -> { hb(0f, -2.8f, ez, 2f, 1.5f, 0.25f, 0x7A2030); hb(0f, -3.3f, ez + 0.03f, 1f, 0.5f, 0.25f, 0xE06A80) }
            4 -> { hb(0f, -2.7f, ez, 2f, 0.7f, 0.25f, mouthC); hb(-1.4f, -2.3f, ez, 0.7f, 0.6f, 0.25f, mouthC); hb(1.4f, -2.3f, ez, 0.7f, 0.6f, 0.25f, mouthC); hb(-0.5f, -3.2f, ez, 0.8f, 0.5f, 0.25f, white) }
            else -> { hb(-0.7f, -2.8f, ez, 1.1f, 0.6f, 0.25f, mouthC); hb(0.7f, -2.8f, ez, 1.1f, 0.6f, 0.25f, mouthC); hb(0f, -2.3f, ez, 0.5f, 0.7f, 0.25f, mouthC); hb(-1.5f, -2.3f, ez, 0.6f, 0.6f, 0.25f, mouthC); hb(1.5f, -2.3f, ez, 0.6f, 0.6f, 0.25f, mouthC) }
        }
        if (L[Look.BLUSH] == 1) { val bl = mixC(skin, 0xFF6F90, 0.5f); hb(2.9f, -1.7f, ez - 0.02f, 1.6f, 0.9f, 0.25f, bl); hb(-2.9f, -1.7f, ez - 0.02f, 1.6f, 0.9f, 0.25f, bl) }

        // ================= CABELO (50 estilos do menu viram formas de bloco) =================
        val hatId = L[Look.HAT]
        val hatCovers = hatId == 2 || hatId == 3 || hatId == 8 || hatId == 16 || hatId == 19 || hatId == 21 || hatId == 22 || hatId == 23
        lay(8, 14)
        val hs = L[Look.HAIR].coerceIn(0, 49)
        val bk = HAIR_BK[hs]; val sl = HAIR_SL[hs]; val bg = HAIR_BG[hs]; val tp = HAIR_TP[hs]; val ext = HAIR_EXT[hs]
        val tie = hatC
        val sway = sin(t * 2.6f) * 2f + sin(ph) * 7f * stride
        val mohawk = ext == 7; val afro = ext == 13
        val hl = if (hatCovers) 0f else tp
        if (!mohawk) {
            if (hatCovers) hb(0f, 3.6f, 0f, 8.6f, 1.2f, 8.6f, hairC)
            else { hb(0f, 4.2f + tp / 2f, 0f, 8.8f, 1.4f + tp, 8.8f, hairC); hb(0f, 4.95f + tp, -0.6f, 6.4f, 0.3f, 5.6f, hairL) }
            val hbk = min(bk, 8f)
            hb(0f, 4.4f - hbk / 2f, -4.2f, 8.8f, hbk, 1.4f, hairC)
            val hsl = min(sl, 8f)
            hb(4.2f, 4.4f - hsl / 2f, 0f, 1.4f, hsl, 8.8f, hairC); hb(-4.2f, 4.4f - hsl / 2f, 0f, 1.4f, hsl, 8.8f, hairC)
            when (bg) {
                1 -> hb(0f, 3.5f, 4.2f, 8.8f, 1.6f, 1.2f, hairC)
                2 -> hb(0f, 3.0f, 4.2f, 8.8f, 2.6f, 1.2f, hairC)
                3 -> hb(0f, 2.6f, 4.2f, 8.8f, 3.4f, 1.2f, hairC)
                4 -> { hb(0f, 3.5f, 4.2f, 8.8f, 1.6f, 1.2f, hairC); hb(-1.2f, 2.4f, 4.2f, 6.4f, 1.2f, 1.2f, hairC); hb(-2.6f, 1.4f, 4.2f, 3.6f, 1.0f, 1.2f, hairC) }
                5 -> { for (k in 0..3) { val xk = -3.3f + 2.2f * k.toFloat(); hb(xk, 3.4f - (if (k % 2 == 0) 0.6f else 0f), 4.2f, 1.9f, 2.4f + (if (k % 2 == 0) 1f else 0f), 1.2f, hairC) } }
                6 -> { hb(-2.3f, 2.9f, 4.2f, 4.2f, 2.6f, 1.2f, hairC); hb(2.3f, 3.1f, 4.2f, 4.2f, 2.2f, 1.2f, hairC); hb(-3.9f, 1.6f, 4.2f, 1.0f, 1.2f, 1.2f, hairC); hb(3.9f, 1.6f, 4.2f, 1.0f, 1.2f, 1.2f, hairC) }
            }
            if (bk > 8f) {
                val len = bk - 8f
                tb(0f, 6f - len / 2f, -3f, 8.6f, len, 1.3f, hairC)
                tb(-1.8f, 6f - len * 0.45f, -3.7f, 2.2f, len * 0.9f, 0.5f, hairD); tb(2.4f, 6f - len * 0.45f, -3.7f, 2.6f, len * 0.9f, 0.5f, hairD)
            }
            if (sl > 8f) {
                val len2 = sl - 8f
                tb(-3.4f, 6f - len2 / 2f + 0.2f, 2.7f, 1.8f, len2, 1f, hairC); tb(3.4f, 6f - len2 / 2f + 0.2f, 2.7f, 1.8f, len2, 1f, hairC)
            }
        }
        when (ext) {
            1 -> if (!hatCovers) { val ls = if (hs == 31) 3.2f else 2.6f; for (k in 0..5) { val xk = floatArrayOf(0f, -2.4f, 2.4f, -2.4f, 2.4f, 0f)[k]; val zk = floatArrayOf(0.5f, -1.8f, -1.8f, 1.6f, 1.6f, -3f)[k]; hb(xk, 5f + ls / 2f + tp, zk, 1.7f, ls + (k % 2).toFloat(), 1.7f, hairC, rz = xk * 3f) } }
            23 -> if (!hatCovers) { for (k in 0..6) { val xk = -3.6f + 1.2f * k.toFloat(); val ls = 4f + (k % 3).toFloat() * 1.4f; hb(xk, 5f + ls / 2f, -0.5f + (k % 2).toFloat() * 1.4f, 1.5f, ls, 1.7f, hairC, rz = xk * 4f) } }
            2 -> for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); hb(gf * 5f, 0.2f, -1f, 2.1f, 1f, 2.1f, tie); hb(gf * 5f, -3.4f, -1f, 1.9f, 6.8f, 1.9f, hairC, rz = gf * sway * 0.5f) }
            3 -> { hb(0f, 3.4f, -4.6f, 2.2f, 2.2f, 1.4f, tie); hb(0f, -1.2f + 0.0f, -5.4f, 2.8f, 9f, 2f, hairC, rx = 6f + sway); hb(0f, -4.8f, -5.6f, 2.4f, 1.5f, 1.6f, hairD, rx = 6f + sway) }
            4 -> if (!hatCovers) { hb(0f, 4.6f + hl, -0.5f, 8.6f, 0.9f, 8.6f, tie); hb(0f, 6.4f + hl, -0.5f, 4.2f, 3.4f, 4.2f, hairC); hb(0f, 8.0f + hl, -0.5f, 2.4f, 0.8f, 2.4f, hairL) }
            5 -> { hb(4.9f, 0.5f, -0.5f, 1.5f, 6f, 7f, hairC); hb(-4.9f, 0.5f, -0.5f, 1.5f, 6f, 7f, hairC); hb(0f, 0f, -4.9f, 9.6f, 8f, 1.5f, hairC) }
            6 -> if (!hatCovers) { hb(0f, 5.2f + tp, 2.2f, 8.4f, 2.2f, 3.6f, hairC); hb(0f, 6.2f + tp, 2.4f, 7f, 0.6f, 2.8f, hairL) }
            7 -> { hb(0f, 4.8f, 0f, 1.8f, 1.6f, 8.8f, hairC); hb(0f, 6.2f, -0.5f, 1.8f, 1.8f, 7f, hairC); hb(0f, 3.9f, 0f, 1.8f, 0.8f, 8.6f, hairD) }
            8 -> { for (k in 0..5) tb(0f, 5.5f - 2.3f * k.toFloat(), -3.1f, 2.4f, 2.4f, 1.5f, if (k % 2 == 0) hairC else hairD); tb(0f, 5.5f - 2.3f * 6f, -3.1f, 2.6f, 1.2f, 1.6f, tie) }
            9 -> if (!hatCovers) { for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); hb(gf * 3.2f, 4.7f, -0.5f, 3.4f, 0.8f, 3.4f, tie); hb(gf * 3.2f, 6.4f, -0.5f, 3.2f, 3.2f, 3.2f, hairC) } }
            10 -> if (!hatCovers) { for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); hb(gf * 4.6f, 3.6f, -1.5f, 2.2f, 1.0f, 2.2f, tie); hb(gf * 5.4f, -3.2f, -1.5f, 2.2f, 11.5f, 2.2f, hairC, rz = gf * (3f + sway * 0.3f)) } }
            11 -> if (!hatCovers) { hb(0.4f, 5.9f + tp, 1.2f, 0.7f, 3.4f, 0.7f, hairC, rz = -18f); hb(1.6f, 7.8f + tp, 1.2f, 0.7f, 1.4f, 0.7f, hairC, rz = -42f) }
            12 -> { hb(5f, 1.5f, 0f, 1.9f, 6.4f, 7.2f, hairC); hb(-5f, 1.5f, 0f, 1.9f, 6.4f, 7.2f, hairC); hb(-2.4f, 5.5f + tp, 0f, 3.4f, 2.4f, 3.4f, hairC); hb(2.4f, 5.4f + tp, 0.4f, 3.4f, 2.2f, 3.4f, hairC); hb(0f, 4.4f, -5f, 7.8f, 3f, 1.6f, hairC) }
            13 -> { hb(0f, 6.2f, -1f, 13f, 5.5f, 12.5f, hairC); hb(5.6f, 2.2f, -1f, 2.6f, 6.5f, 11f, hairC); hb(-5.6f, 2.2f, -1f, 2.6f, 6.5f, 11f, hairC); hb(0f, 2f, -5.8f, 12.6f, 9f, 2.8f, hairC); hb(0f, 8.7f, -1f, 9.5f, 0.6f, 9.5f, hairL) }
            14 -> { for (k in -3..3) { val kf = k.toFloat(); val lg = 8f + (k and 1).toFloat() * 2f + abs(kf); hb(kf * 1.15f, 0.5f - lg / 2f + 2f, -4.9f, 1.1f, lg, 1.2f, if (k % 2 == 0) hairC else hairD) }; for (g in intArrayOf(-1, 1)) for (k in 0..2) { val gf = g.toFloat(); hb(gf * 4.9f, 0.5f - (k * 1.5f), -3f + k.toFloat() * 1.7f, 1.2f, 6f + k.toFloat(), 1.1f, hairC) } }
            15 -> if (!hatCovers) { hb(0f, 6.2f, -2.2f, 2.6f, 3f, 2.6f, hairC); hb(0f, 4.7f, -2.2f, 3.2f, 0.8f, 3.2f, tie) }
            16 -> { hb(0f, -1.6f, -4.8f, 2.2f, 1.4f, 1.4f, tie); hb(0f, -5.6f, -5.2f, 2.4f, 8f, 1.8f, hairC, rx = 4f + sway * 0.7f) }
            18 -> { for (k in 0..4) tb(-3.6f, 3.5f - 2.2f * k.toFloat(), 2.7f, 2.2f, 2.2f, 1.4f, if (k % 2 == 0) hairC else hairD); tb(-3.6f, 3.5f - 2.2f * 5f, 2.7f, 2.4f, 1.1f, 1.5f, tie) }
            19 -> { for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); for (k in 0..4) tb(gf * 3.6f, 3.5f - 2.2f * k.toFloat(), 2.7f, 2.2f, 2.2f, 1.4f, if (k % 2 == 0) hairC else hairD); tb(gf * 3.6f, 3.5f - 2.2f * 5f, 2.7f, 2.4f, 1.1f, 1.5f, tie) } }
            20 -> if (!hatCovers) { hb(0f, 5.5f, -1.4f, 3.4f, 3f, 3.4f, hairC); hb(0f, 4.4f, -1.4f, 3.8f, 0.8f, 3.8f, tie) }
            22 -> { for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); hb(gf * 4.6f, 3.6f, -1.5f, 2.2f, 1.0f, 2.2f, tie); for (k in 0..4) hb(gf * (5.2f + (k % 2).toFloat() * 0.6f), 1.8f - 2.2f * k.toFloat(), -1.5f, 2.5f, 2.4f, 2.5f, if (k % 2 == 0) hairC else hairD) } }
        }


        // Mechas de cor que respeitam a escolha do menu e criam reflexos volumétricos.
        if(!hatCovers && hairAccentStyle>0) {
            lay(10,14)
            val hairShadow=shadeC(accentHair,0.68f); val hairLight=lite(accentHair,0.34f)
            when(hairAccentStyle) {
                1 -> { hb(0f,3.45f,4.58f,0.95f,2.35f,0.16f,hairShadow); hb(0f,3.48f,4.68f,0.56f,2.05f,0.08f,accentHair); hb(0f,4.72f,4.2f,0.45f,0.2f,0.08f,hairLight) }
                2 -> for(x in intArrayOf(-2,2)) { hb(x.toFloat(),3.5f,4.58f,0.7f,2.05f,0.14f,hairShadow); hb(x.toFloat(),3.55f,4.67f,0.4f,1.8f,0.08f,accentHair) }
                3 -> for(x in intArrayOf(-3,-2,2,3)) hb(x.toFloat(),1f,4.5f,0.55f,0.6f,0.14f,accentHair)
                4 -> for(k in 0..4) { val x=-2.6f+k*1.3f; hb(x,3.4f,4.58f,0.55f,1.6f,0.14f,hairShadow,rz=(k-2)*4f); hb(x,3.45f,4.67f,0.3f,1.4f,0.08f,if(k%2==0) accentHair else hairLight,rz=(k-2)*4f) }
                5 -> for(x in intArrayOf(-3,-1,1,3)) hb(x.toFloat(),4.98f,-0.5f,0.24f,0.08f,3f,hairLight)
                6 -> for(x in intArrayOf(-1,1)) { hb(x*3.35f,0.6f,4.35f,0.7f,2.9f,0.14f,hairShadow); hb(x*3.35f,0.55f,4.45f,0.42f,2.65f,0.08f,accentHair) }
                7 -> for(k in 0..6) hb(-3f+k,4.98f,-0.4f,0.2f,0.07f,3.2f,if(k%2==0) accentHair else hairLight)
                8 -> for(x in intArrayOf(-1,1)) hb(x*1.4f,4.96f,-0.5f,0.14f,0.06f,2.5f,accentHair)
            }
        }

        // Textura do cabelo em pixels: mechas com sombra própria e reflexo curto.
        // O padrão muda por corte para não parecer uma única peruca recolorida.
        if(!hatCovers && hs != 13 && hs != 37) {
            lay(10,14)
            val strandShadow=shadeC(hairC,0.68f)
            val strandLight=lite(hairC,0.28f)
            for(k in 0..6) {
                val x=-3f+k.toFloat()
                val offset=((hs+k*3)%3).toFloat()*0.22f
                val len=if((hs+k)%4==0) 0.58f else 1.0f
                val y=3.45f-offset
                if((hs+k)%3!=0) hb(x,y,4.52f,0.24f,len,0.08f,strandShadow)
                if((hs+k)%2==0) hb(x-0.08f,y+0.18f,4.58f,0.12f,len*0.58f,0.06f,strandLight)
            }
            // Pequenos pixels de brilho no topo, com intervalos irregulares como uma textura 64x64.
            for(k in 0..5) {
                val x=-2.7f+k*1.05f
                hb(x,4.83f,0.15f,0.34f,0.08f,0.62f,if((k+hs)%3==0) strandShadow else strandLight)
            }
        }

        // Franja e silhueta frontal específica por família de corte.
        // As formas são blocos pequenos em degraus, como os pixels de uma skin bem desenhada.
        if(!hatCovers) {
            lay(11,15)
            val fringeShadow=shadeC(hairC,0.66f)
            val fringeHi=lite(hairC,0.22f)
            when(hs) {
                0,24,40 -> { // curto / pixie / cacheado curto
                    hb(-2.4f,3.15f,4.56f,1.25f,1.25f,0.12f,hairC,rz=8f)
                    hb(-0.8f,3.55f,4.58f,1.15f,1.65f,0.12f,hairC,rz=-5f)
                    hb(1.0f,3.25f,4.57f,1.05f,1.25f,0.12f,fringeShadow)
                    hb(1.0f,3.42f,4.64f,0.48f,0.82f,0.06f,fringeHi)
                }
                1,12,14,23,49 -> { // espetado, saiyajin, moicano, pompadour, twin drills
                    for(k in 0..3) {
                        val x=-2.7f+k*1.65f
                        val h=if((k+hs)%2==0) 1.7f else 1.1f
                        hb(x,3.9f+h*0.38f,4.25f,1.15f,h,1.15f,hairC,rz=(k-1.5f)*-8f)
                        hb(x-0.12f,3.95f+h*0.38f,4.58f,0.28f,h*0.55f,0.08f,fringeHi,rz=(k-1.5f)*-8f)
                    }
                }
                2,6,16,29,32,44,48 -> { // chanel, longo, hime, cortina, liso, princesa, cachos de princesa
                    for(k in 0..4) {
                        val x=-2.6f+k*1.3f
                        val drop=when(k) { 0,4 -> 0.95f; 1,3 -> 1.45f; else -> 0.7f }
                        hb(x,3.45f-drop*0.35f,4.58f,0.95f,0.85f+drop,0.12f,hairC,rz=(k-2)*3f)
                        if(k%2==0) hb(x,3.7f,4.66f,0.22f,0.58f,0.06f,fringeHi)
                    }
                }
                3,18,19,46 -> { // maria-chiquinha, dois coques, twintail alto, tranças duplas
                    for(x in intArrayOf(-2,0,2)) hb(x.toFloat(),3.35f,4.58f,1.15f,1.15f,0.12f,hairC,rz=x*2f)
                    for(x in intArrayOf(-2,2)) hb(x.toFloat(),3.8f,4.66f,0.25f,0.48f,0.06f,fringeHi)
                }
                4,5,17,39,42,43,45,47 -> { // rabos, coque, tranças e meio preso
                    hb(-1.8f,3.2f,4.58f,1.2f,1.3f,0.12f,hairC,rz=14f)
                    hb(-0.7f,3.65f,4.6f,1.1f,1.65f,0.12f,hairC,rz=-8f)
                    hb(-0.8f,3.7f,4.68f,0.24f,0.8f,0.06f,fringeHi)
                }
                8,21,30,37 -> { // undercut, degradê, slick back e militar
                    hb(1.4f,3.8f,4.55f,2.7f,0.55f,0.12f,hairC,rz=-8f)
                    hb(0.8f,4.05f,4.62f,1.4f,0.18f,0.06f,fringeHi)
                }
                9,15,22,27,36,41 -> { // franja lateral, repartido, social, mullet, emo, bob assimétrico
                    for(k in 0..3) {
                        val x=2.2f-k*1.35f
                        val y=3.7f-k*0.42f
                        hb(x,y,4.58f,1.35f,0.95f,0.12f,hairC,rz=-18f)
                    }
                    hb(0.7f,3.65f,4.66f,0.25f,1.1f,0.06f,fringeHi,rz=-18f)
                }
                10,31,33,34 -> { // bagunçado, wolf, ondulado e cacheado longo
                    for(k in 0..5) {
                        val x=-3f+k*1.2f
                        val y=3.35f+((k+hs)%3)*0.38f
                        hb(x,y,4.6f,1.05f,1.1f+((k+hs)%2)*0.35f,0.14f,if(k%3==0) fringeShadow else hairC,rz=(k-2)*5f)
                        if(k%2==0) hb(x-0.12f,y+0.18f,4.68f,0.22f,0.45f,0.06f,fringeHi)
                    }
                }
                11,28 -> { // topete e coque samurai
                    hb(-1.4f,4.0f,4.42f,2.5f,1.45f,1.1f,hairC,rz=14f)
                    hb(-1.2f,4.35f,4.62f,1.25f,0.35f,0.08f,fringeHi,rz=14f)
                    hb(1.2f,3.45f,4.58f,1.0f,0.9f,0.12f,hairC)
                }
                13 -> { /* raspado: não criar franja falsa */ }
                25,26,35 -> { // black power, dreads e box braids: locks separados, não um capacete liso
                    for(k in 0..4) {
                        val x=-2.4f+k*1.2f
                        hb(x,3.35f,4.58f,0.72f,1.35f,0.16f,if(k%2==0) hairC else fringeShadow,rz=(k-2)*4f)
                        hb(x,3.1f,4.68f,0.3f,0.42f,0.07f,fringeHi)
                    }
                }
                38 -> { // cogumelo: franja horizontal característica
                    hb(0f,3.05f,4.58f,7.3f,1.25f,0.16f,hairC)
                    for(x in intArrayOf(-2,0,2)) hb(x.toFloat(),3.12f,4.68f,0.3f,0.75f,0.06f,fringeHi)
                }
                7,20 -> { // fofo e ahoge
                    for(x in intArrayOf(-2,0,2)) hb(x.toFloat(),3.4f,4.58f,1.35f,1.35f,0.16f,hairC,rz=x*3f)
                    hb(0.2f,5.3f,0.1f,0.45f,1.5f,0.45f,hairC,rz=-16f)
                }
            }
        }
        // ================= CHAPÉUS E ENFEITES =================
        lay(13, 19)
        when (hatId) {
            1 -> { hb(0f, 4.45f + hl, 0f, 13f, 0.9f, 13f, hatC); hb(0f, 5.0f + hl, 0f, 8.7f, 0.8f, 8.7f, gold); hb(0f, 6.2f + hl, 0f, 8.4f, 1.8f, 8.4f, hatC); hb(0.3f, 7.9f + hl, 0f, 6.4f, 1.6f, 6.4f, hatC, rz = 4f); hb(0.9f, 9.4f + hl, 0f, 4.4f, 1.6f, 4.4f, hatC, rz = 8f); hb(1.9f, 10.8f + hl, 0f, 2.4f, 1.4f, 2.4f, hatC, rz = 14f) }
            2 -> { hb(0f, 3.6f, 0f, 9.2f, 5f, 9.2f, hatC); hb(0f, 1.7f, 0f, 9.5f, 1.5f, 9.5f, lite(hatC, 0.3f)); hb(0f, 6.9f, 0f, 2.6f, 2.6f, 2.6f, white) }
            3 -> { hb(0f, 3.5f, 0f, 9f, 3.6f, 9f, hatC); hb(0f, 1.9f, 6.2f, 8f, 0.7f, 4.4f, shadeC(hatC, 0.8f)); hb(0f, 5.5f, 0f, 1.2f, 0.6f, 1.2f, lite(hatC, 0.4f)) }
            4 -> { hb(0f, 4.6f + hl, 0f, 8.8f, 1.4f, 8.8f, gold); val cx = floatArrayOf(-3.4f, 3.4f, -3.4f, 3.4f, 0f, 0f); val cz = floatArrayOf(-3.4f, -3.4f, 3.4f, 3.4f, 3.6f, -3.6f); for (k in 0..5) hb(cx[k], 6.2f + hl, cz[k], 1.6f, 2.4f, 1.6f, gold); hb(0f, 4.6f + hl, 4.5f, 1f, 1f, 0.3f, 0xE05555) }
            5 -> for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); hb(gf * 2.8f, 5.6f + hl, -0.5f, 2.6f, 2.2f, 1.2f, hairC); hb(gf * 2.8f, 7.1f + hl, -0.5f, 1.4f, 1.2f, 1f, hairC); hb(gf * 2.8f, 5.6f + hl, 0.2f, 1.4f, 1.2f, 0.3f, 0xF0A0B0) }
            6 -> for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); hb(gf * 2f, 8.6f + hl, -0.5f, 2f, 7f, 1f, hairC, rz = gf * -8f); hb(gf * 2f, 8.6f + hl, 0.1f, 1f, 5.2f, 0.3f, 0xF0A0B0, rz = gf * -8f) }
            7 -> { hb(0f, 5.3f + hl, 2f, 1.8f, 1.8f, 1.4f, hatC); hb(-2.6f, 5.6f + hl, 2f, 3.2f, 3f, 1f, hatC, rz = 14f); hb(2.6f, 5.6f + hl, 2f, 3.2f, 3f, 1f, hatC, rz = -14f) }
            8 -> { hb(0f, 3.8f, 0f, 9.4f, 3f, 9.4f, steel); hb(4.6f, 0.2f, 0f, 1.2f, 6f, 9f, steel); hb(-4.6f, 0.2f, 0f, 1.2f, 6f, 9f, steel); hb(0f, 0.2f, -4.6f, 9.4f, 6f, 1.2f, steel); hb(0f, 2.4f, 4.6f, 9.4f, 1f, 1.2f, lite(steel, 0.3f)); hb(0f, 5.8f, 0f, 1.6f, 1.6f, 8f, hatC) }
            9 -> { hb(0f, 3.6f + hl, 0f, 14f, 0.8f, 14f, 0xE8C86A); hb(0f, 5.2f + hl, 0f, 7.6f, 2.6f, 7.6f, 0xE8C86A); hb(0f, 4.4f + hl, 0f, 7.9f, 0.8f, 7.9f, hatC) }
            10 -> { hb(3.2f, 4.9f + hl, 1.5f, 1f, 1f, 1f, 0xFFD35C); hb(3.2f, 4.9f + hl, 2.6f, 1.3f, 1f, 1.3f, hatC); hb(3.2f, 4.9f + hl, 0.4f, 1.3f, 1f, 1.3f, hatC); hb(4.3f, 4.9f + hl, 1.5f, 1.3f, 1f, 1.3f, hatC); hb(2.1f, 4.9f + hl, 1.5f, 1.3f, 1f, 1.3f, hatC) }
            11 -> { hb(0f, 2.2f, 0f, 8.9f, 1.6f, 8.9f, hatC); hb(0f, 2.2f, 4.5f, 3.4f, 1.6f, 0.3f, steel); hb(1.2f, 2.2f, -5.2f, 1.2f, 3.5f, 0.8f, hatC, rz = -15f); hb(-1.2f, 1.5f, -5.4f, 1.2f, 3.5f, 0.8f, hatC, rz = 15f) }
            12 -> { hb(0f, 8f + hl, 3.2f, 7f, 0.5f, 0.8f, gold); hb(0f, 8f + hl, -3.2f, 7f, 0.5f, 0.8f, gold); hb(3.2f, 8f + hl, 0f, 0.8f, 0.5f, 7f, gold); hb(-3.2f, 8f + hl, 0f, 0.8f, 0.5f, 7f, gold) }
            13 -> for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); hb(gf * 2.6f, 5.2f + hl, 0.5f, 1.4f, 2f, 1.4f, hatC); hb(gf * 3.1f, 6.7f + hl, 0.5f, 1f, 1.4f, 1f, hatC, rz = gf * -15f) }
            14 -> for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); hb(gf * 3f, 6.2f + hl, -0.5f, 2.8f, 3.4f, 1.2f, hairC); hb(gf * 3f, 8.4f + hl, -0.5f, 1.4f, 1.4f, 1f, shadeC(hairC, 0.4f)); hb(gf * 3f, 6.2f + hl, 0.2f, 1.5f, 2f, 0.3f, 0xF4D0C0) }
            15 -> { hb(0f, 4.6f + hl, 0f, 8.7f, 0.6f, 8.7f, gold); hb(0f, 5.4f + hl, 4.1f, 2f, 1.4f, 0.5f, gold); hb(0f, 5.4f + hl, 4.4f, 0.8f, 0.8f, 0.3f, 0x6AA8F0) }
            16 -> { hb(0.6f, 4.4f, 0f, 10f, 1.8f, 9.6f, hatC); hb(0.6f, 5.6f, 0f, 1f, 1f, 1f, shadeC(hatC, 0.7f)) }
            17 -> { hb(0f, 4.6f + hl, 0f, 14f, 0.8f, 14f, 0xD8B070); hb(0f, 5.4f + hl, 0f, 10.4f, 0.8f, 10.4f, 0xD8B070); hb(0f, 6.2f + hl, 0f, 6.8f, 0.8f, 6.8f, 0xD8B070); hb(0f, 6.9f + hl, 0f, 3.2f, 0.8f, 3.2f, hatC) }
            18 -> { hb(0f, 5.0f + hl, 0f, 9.6f, 0.9f, 1.4f, hatC); for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); hb(gf * 4.8f, 3.3f + hl, 0f, 0.9f, 3.2f, 1.4f, hatC); hb(gf * 5.0f, 0.8f, 0f, 1.6f, 3.2f, 3.4f, hatC); hb(gf * 5.9f, 0.8f, 0f, 0.4f, 2.4f, 2.6f, lite(hatC, 0.4f)) } }
            19 -> { hb(0f, 4.1f, 0f, 9.8f, 2.2f, 9.8f, hatC); hb(0f, 0.4f, -4.7f, 9.8f, 7.5f, 1.8f, hatC); hb(4.7f, 1f, -0.3f, 1.8f, 6.5f, 8.4f, hatC); hb(-4.7f, 1f, -0.3f, 1.8f, 6.5f, 8.4f, hatC); hb(0f, 3.3f, 4.7f, 9.6f, 1.2f, 0.9f, shadeC(hatC, 0.8f)); tb(0f, 5.7f, -1.8f, 9.6f, 2.6f, 2.2f, hatC) }
            20 -> { hb(0f, 4.4f + hl, 0f, 9f, 1.2f, 9f, white); hb(0f, 5.1f + hl, 4.2f, 8f, 1f, 1.2f, white); hb(0f, 5.0f + hl, 0f, 7.6f, 1.6f, 7.6f, white); hb(0f, 4.2f + hl, -4.8f, 3f, 2.2f, 0.8f, white) }
            21 -> { hb(0f, 4.3f, 0f, 11f, 0.8f, 11f, hatC); hb(0f, 8.2f, 0f, 7.6f, 7.6f, 7.6f, hatC); hb(0f, 5.6f, 0f, 7.9f, 1.2f, 7.9f, shadeC(hatC, 0.5f)) }
            22 -> { hb(0f, 4.6f, 0f, 8.8f, 1.6f, 8.8f, white); hb(0f, 7.4f, 0f, 10f, 4.6f, 10f, white); hb(0f, 10f, 0f, 8.4f, 1f, 8.4f, white) }
            23 -> { hb(0f, 4.2f, 0f, 9.6f, 2.4f, 9.6f, steel); hb(4.8f, 1.6f, 0f, 0.9f, 3.2f, 8.4f, steel); hb(-4.8f, 1.6f, 0f, 0.9f, 3.2f, 8.4f, steel); hb(0f, 2.4f, 4.9f, 1f, 4f, 0.8f, steel); for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); hb(gf * 5.6f, 4.6f, 0f, 1.6f, 1.6f, 1.6f, 0xF0E8D0); hb(gf * 6.6f, 6f, 0f, 1.4f, 2.2f, 1.4f, 0xF0E8D0, rz = gf * -20f); hb(gf * 7.3f, 7.8f, 0f, 1f, 1.4f, 1f, 0xF0E8D0, rz = gf * -35f) } }
        }


        // Relevos materiais por família de chapéu, coroa, fone e capacete.
        lay(15,19)
        when(hatId) {
            1 -> { hb(0f,4.55f+hl,4.45f,0.9f,0.75f,0.12f,accentTop); hb(0f,4.55f+hl,4.55f,0.38f,0.38f,0.08f,metalHi) }
            2 -> for(k in -2..2) hb(k*1.25f,2f,4.55f,0.3f,0.12f,0.08f,lite(hatC,0.3f))
            3 -> { hb(0f,2f,4.6f,2.2f,0.25f,0.1f,shadeC(hatC,0.65f)); hb(0f,2.12f,4.68f,1.25f,0.1f,0.06f,accentTop) }
            4,15 -> for(x in intArrayOf(-2,0,2)) { hb(x.toFloat(),5.6f+hl,4.55f,0.78f,0.78f,0.12f,shadeC(accentTop,0.62f),rz=45f); hb(x.toFloat(),5.6f+hl,4.64f,0.46f,0.46f,0.08f,accentTop,rz=45f) }
            5,6,14 -> for(x in intArrayOf(-1,1)) { hb(x*2.8f,5.6f+hl,0.28f,0.75f,1.15f,0.12f,accentTop); hb(x*2.8f,5.55f+hl,0.37f,0.34f,0.7f,0.08f,lite(accentTop,0.28f)) }
            8,23 -> { for(x in intArrayOf(-3,3)) for(y in intArrayOf(2,-1)) hb(x.toFloat(),y.toFloat(),4.8f,0.3f,0.3f,0.1f,gold); hb(0f,2.5f,4.9f,1.1f,1.1f,0.12f,accentTop) }
            9,17 -> for(x in intArrayOf(-3,-1,1,3)) hb(x.toFloat(),4.15f+hl,4.5f,0.18f,0.1f,0.08f,shadeC(hatC,0.7f))
            11 -> { hb(0f,2.2f,4.65f,4.8f,0.18f,0.1f,metalHi); hb(0f,2.2f,4.72f,2f,0.1f,0.06f,accentTop) }
            16 -> { hb(1f,4.5f,4.8f,1.15f,0.7f,0.12f,shadeC(hatC,0.62f)); hb(1f,4.5f,4.9f,0.58f,0.32f,0.08f,accentTop) }
            18 -> { for(x in intArrayOf(-5,5)) for(y in intArrayOf(0,2)) hb(x.toFloat(),y.toFloat(),1.85f,0.2f,0.2f,0.1f,metalHi); hb(-5.6f,-0.1f,2.1f,0.32f,0.72f,0.14f,0x73E7FF) }
            19,20 -> for(x in intArrayOf(-3,3)) hb(x.toFloat(),1.6f,4.65f,0.18f,4f,0.1f,lite(hatC,0.25f))
            21 -> { hb(0f,5.15f,4.8f,5.3f,0.25f,0.1f,shadeC(hatC,0.6f)); hb(0f,5.3f,4.9f,2.1f,0.14f,0.07f,accentTop) }
        }
        // ================= ROSTO: óculos e marcas =================
        lay(7, 12)
        val gz = 4.3f
        val blk = 0x1E1E26
        fun frame(cx: Float, w: Float, h: Float, c: Int, lens: Int, la: Float) {
            hb(cx, eyeY - 0.2f, gz, w - 0.4f, h - 0.4f, 0.2f, lens, la)
            hb(cx, eyeY - 0.2f + h / 2f, gz + 0.05f, w, 0.4f, 0.3f, c); hb(cx, eyeY - 0.2f - h / 2f, gz + 0.05f, w, 0.4f, 0.3f, c)
            hb(cx - w / 2f, eyeY - 0.2f, gz + 0.05f, 0.4f, h, 0.3f, c); hb(cx + w / 2f, eyeY - 0.2f, gz + 0.05f, 0.4f, h, 0.3f, c)
        }
        fun temples(c: Int) { for (g in intArrayOf(-1, 1)) hb(g.toFloat() * 4.1f, eyeY + 0.2f, 1.9f, 0.3f, 0.4f, 4.4f, c) }
        when (L[Look.FACE]) {
            1 -> { frame(2f, 3f, 2.8f, blk, 0x9AD8F0, 0.3f); frame(-2f, 3f, 2.8f, blk, 0x9AD8F0, 0.3f); hb(0f, eyeY + 0.3f, gz + 0.05f, 1f, 0.4f, 0.3f, blk); temples(blk) }
            2 -> { frame(2f, 3.4f, 2.2f, blk, blk, 0.92f); frame(-2f, 3.4f, 2.2f, blk, blk, 0.92f); hb(0f, eyeY + 0.3f, gz + 0.05f, 0.8f, 0.4f, 0.3f, blk); temples(blk) }
            3 -> { val fx = floatArrayOf(2.4f, 3.3f, 1.7f, -2.4f, -3.3f, -1.7f); val fy = floatArrayOf(-1.4f, -1.9f, -2.0f, -1.4f, -1.9f, -2.0f); for (k in 0..5) hb(fx[k], fy[k], 4.08f, 0.5f, 0.5f, 0.2f, shadeC(skin, 0.7f)) }
            4 -> { hb(-2f, eyeY - 0.2f, gz, 3.2f, 2.6f, 0.4f, blk); hb(0f, eyeY + 2.4f, gz - 0.1f, 8.4f, 0.5f, 0.3f, blk, rz = -8f) }
            5 -> { val sx = floatArrayOf(2.7f, 2.1f, 1.5f, 0.9f); val sy = floatArrayOf(eyeY + 2.2f, eyeY + 1.2f, eyeY + 0.2f, eyeY - 0.8f); for (k in 0..3) hb(sx[k], sy[k], 4.1f, 0.65f, 0.65f, 0.25f, 0xC45A5A) }
            6 -> { hb(2.8f, -1.9f, 4.1f, 2.6f, 1.1f, 0.3f, 0xF0D7B0); hb(2.2f, -1.9f, 4.25f, 0.3f, 0.3f, 0.2f, 0xC9A97E); hb(3.4f, -1.9f, 4.25f, 0.3f, 0.3f, 0.2f, 0xC9A97E) }
            7 -> { for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); hb(gf * 3.3f, -1.4f, 4.15f, 2f, 0.25f, 0.2f, blk, rz = gf * 10f); hb(gf * 3.4f, -2.1f, 4.15f, 2f, 0.25f, 0.2f, blk); hb(gf * 3.3f, -2.8f, 4.15f, 2f, 0.25f, 0.2f, blk, rz = gf * -10f) } }
            8 -> { hb(0f, -2.4f, 4.2f, 8.4f, 3.4f, 0.5f, 0xF2F2F2); hb(0f, -2.4f, 4.5f, 8f, 0.25f, 0.2f, 0xD0D6DE); hb(0f, -3.2f, 4.5f, 8f, 0.25f, 0.2f, 0xD0D6DE); for (g in intArrayOf(-1, 1)) hb(g.toFloat() * 4.25f, -1.8f, 1.2f, 0.3f, 0.6f, 5.2f, white) }
            9 -> { frame(2f, 3.2f, 2.4f, blk, 0x9AD8F0, 0.28f); frame(-2f, 3.2f, 2.4f, blk, 0x9AD8F0, 0.28f); hb(0f, eyeY + 0.3f, gz + 0.05f, 0.8f, 0.4f, 0.3f, blk); temples(blk) }
            10 -> hb(2.5f, eyeY - 1.6f, 4.15f, 0.7f, 1.2f, 0.3f, 0x6AB8F0)
            11 -> { frame(2f, 3.2f, 3.2f, gold, 0xFFFFFF, 0.15f); hb(4.2f, -3f, 3.8f, 0.3f, 3.5f, 0.3f, gold) }
            12 -> { frame(2f, 3.8f, 3f, gold, 0xE8A030, 0.5f); frame(-2f, 3.8f, 3f, gold, 0xE8A030, 0.5f); hb(0f, eyeY + 0.8f, gz + 0.05f, 0.8f, 0.4f, 0.3f, gold); temples(gold) }
        }


        // ================= ACABAMENTO 3D DOS ACESSÓRIOS FACIAIS =================
        // Reflexos de lente, reforço de armação, pontos de costura e detalhes de máscara.
        lay(8,12)
        when(L[Look.FACE]) {
            1,9 -> { // óculos redondos/quadrados
                for(x in intArrayOf(-2,2)) {
                    hb(x.toFloat()-0.4f,eyeY+0.55f,gz+0.16f,0.72f,0.16f,0.07f,0xFFFFFF,0.72f)
                    hb(x.toFloat(),eyeY+1.2f,gz+0.15f,0.18f,0.18f,0.06f,lite(blk,0.5f))
                }
                hb(0f,eyeY+0.25f,gz+0.17f,0.7f,0.14f,0.08f,metalHi)
            }
            2 -> { // lentes escuras com reflexo
                for(x in intArrayOf(-2,2)) {
                    hb(x.toFloat()-0.45f,eyeY+0.5f,gz+0.16f,1.05f,0.18f,0.08f,0xD5ECFF,0.72f)
                    hb(x.toFloat(),eyeY-0.8f,gz+0.16f,2.25f,0.1f,0.07f,lite(blk,0.3f))
                }
            }
            3 -> { // sardas com dois tons para não parecerem pontos chapados
                for(x in intArrayOf(-3,-2,2,3)) hb(x.toFloat(),-1.55f,4.2f,0.18f,0.18f,0.08f,lite(skin,0.18f))
            }
            4 -> { // tapa-olho: costura e fivela lateral
                hb(-2f,eyeY-0.2f,4.25f,2.65f,0.12f,0.08f,shadeC(blk,0.72f))
                hb(-3.8f,eyeY-0.2f,4.28f,0.25f,0.55f,0.12f,metalHi)
            }
            5 -> { // cicatriz em camadas
                for(k in 0..3) hb(2.7f-k*0.55f,eyeY+1.8f-k*0.9f,4.28f,0.72f,0.12f,0.08f,shadeC(0xC45A5A,0.72f),rz=-42f)
                for(k in 0..2) hb(2.5f-k*0.55f,eyeY+1.55f-k*0.9f,4.34f,0.35f,0.08f,0.06f,lite(0xC45A5A,0.22f),rz=-42f)
            }
            6 -> { // curativo com costuras visíveis
                hb(2.8f,-1.9f,4.34f,1.8f,0.12f,0.06f,shadeC(0xC9A97E,0.7f))
                for(k in 0..3) hb(2.2f+k*0.4f,-1.9f,4.38f,0.12f,0.34f,0.06f,0xA58B68)
            }
            7 -> { // bigodes de gato e nariz em volume
                hb(0f,eyeY-1.35f,4.4f,0.45f,0.32f,0.18f,0x5A3345)
                for(x in intArrayOf(-1,1)) hb(x*0.7f,eyeY-1.25f,4.51f,0.2f,0.12f,0.08f,lite(0xE59AAA,0.3f))
            }
            8 -> { // máscara: costura central e filtros laterais
                hb(0f,-2.45f,4.55f,0.12f,2.8f,0.08f,0xB8C0CC)
                for(x in intArrayOf(-3,3)) {
                    hb(x.toFloat(),-2.4f,4.58f,0.52f,0.52f,0.1f,shadeC(0xD0D6DE,0.7f))
                    hb(x.toFloat(),-2.4f,4.66f,0.3f,0.3f,0.06f,metalHi)
                }
                for(x in intArrayOf(-2,2)) hb(x.toFloat(),-1.6f,4.58f,0.14f,0.14f,0.07f,0x8893A3)
            }
            10 -> { // lágrima com ponto especular
                hb(2.35f,eyeY-1.15f,4.34f,0.22f,0.28f,0.08f,0xB8F1FF,0.85f)
            }
            11 -> { // monóculo: reflexo e corrente
                hb(1.35f,eyeY+0.55f,4.52f,0.7f,0.16f,0.08f,0xFFFFFF,0.82f)
                for(k in 0..3) hb(4.2f+k*0.18f,eyeY-0.8f-k*0.65f,4.12f,0.16f,0.16f,0.07f,gold)
            }
            12 -> { // aviador: ponte metálica e brilhos quentes no vidro
                for(x in intArrayOf(-2,2)) hb(x.toFloat(),eyeY+0.65f,4.54f,1.15f,0.18f,0.08f,0xFFF0BC,0.72f)
                hb(0f,eyeY+0.3f,4.5f,0.85f,0.2f,0.12f,gold)
                for(x in intArrayOf(-4,4)) hb(x.toFloat(),eyeY+0.1f,4.32f,0.15f,0.4f,0.12f,metalHi)
            }
        }

        // ================= PESCOÇO =================
        lay(9, 12)
        when (L[Look.NECK]) {
            1 -> { tb(0f, 5.2f, 0f, 9.2f, 2.2f, 5.2f, neckC); tb(2.5f, 2.2f, 2.8f, 2f, 6.5f, 0.7f, neckC); tb(2.5f, 0.5f, 2.85f, 2.05f, 0.8f, 0.5f, lite(neckC, 0.5f)) }
            2 -> { tb(0f, 5.2f, 2.55f, 1.4f, 1.4f, 0.6f, neckC); tb(-1.6f, 5.2f, 2.5f, 2f, 2.4f, 0.5f, neckC, rz = 15f); tb(1.6f, 5.2f, 2.5f, 2f, 2.4f, 0.5f, neckC, rz = -15f) }
            3 -> { tb(0f, 5.1f, 2.45f, 5.6f, 0.4f, 0.3f, gold); tb(0f, 4f, 2.55f, 1.3f, 1.3f, 0.3f, neckC) }
            4 -> { tb(0f, 5f, 2.55f, 1.8f, 1.4f, 0.5f, neckC); tb(0f, 1.4f, 2.55f, 1.8f, 6.4f, 0.4f, neckC); tb(0f, -1.9f, 2.55f, 1.8f, 0.8f, 0.4f, shadeC(neckC, 0.8f)) }
            5 -> { tb(0f, 5.2f, 2.55f, 1.2f, 1.2f, 0.5f, neckC); tb(-1.7f, 5.2f, 2.5f, 2.2f, 2f, 0.4f, neckC); tb(1.7f, 5.2f, 2.5f, 2.2f, 2f, 0.4f, neckC) }
            6 -> { tb(0f, 5.4f, 0f, 8.5f, 1f, 4.5f, neckC); tb(0f, 4.6f, 2.45f, 1f, 1f, 0.5f, gold) }
            7 -> { tb(0f, 5.3f, 0f, 8.9f, 1.4f, 4.9f, neckC); tb(0f, 3.6f, 2.5f, 3.2f, 1.2f, 0.4f, neckC); tb(0f, 2.6f, 2.52f, 1.8f, 1f, 0.4f, neckC); tb(0f, 1.8f, 2.54f, 0.8f, 0.8f, 0.4f, neckC) }
            8 -> tb(0f, 5.4f, 0f, 8.4f, 0.6f, 4.4f, neckC)
            9 -> { tb(-1.4f, 4.5f, 2.45f, 0.4f, 2.6f, 0.3f, gold, rz = -25f); tb(1.4f, 4.5f, 2.45f, 0.4f, 2.6f, 0.3f, gold, rz = 25f); tb(0f, 2.6f, 2.55f, 1.8f, 1.8f, 0.4f, gold) }
        }


        lay(11,15)
        when(L[Look.NECK]) {
            1 -> { tb(0f,4.65f,2.72f,8.5f,0.16f,0.1f,lite(neckC,0.3f)); for(x in intArrayOf(-3,3)) tb(x.toFloat(),4.2f,2.72f,0.16f,0.55f,0.1f,shadeC(neckC,0.7f)) }
            2,5 -> { tb(0f,5.2f,2.82f,0.55f,0.55f,0.14f,metalHi); tb(0f,5.2f,2.92f,0.26f,0.26f,0.1f,accentTop) }
            3,9 -> { tb(0f,2.9f,2.8f,0.16f,1.25f,0.12f,gold); tb(0f,2.35f,2.88f,0.78f,0.78f,0.14f,gold,rz=45f); tb(0f,2.35f,3f,0.4f,0.4f,0.08f,accentTop,rz=45f) }
            4 -> { tb(0f,3.9f,2.8f,0.22f,0.4f,0.1f,gold); tb(0f,3.45f,2.85f,0.95f,0.18f,0.1f,accentTop) }
            6 -> { tb(-3f,5.1f,2.75f,0.22f,0.4f,0.1f,gold); tb(-3f,4.75f,2.82f,0.4f,0.22f,0.1f,white) }
            7 -> for(x in intArrayOf(-2,0,2)) tb(x.toFloat(),5.65f,2.68f,0.5f,0.16f,0.1f,accentTop)
        }
        // ================= COSTAS =================
        lay(2, 6)
        val flap = sin(t * 9f) * (10f + 14f * mv)
        when (L[Look.BACK]) {
            1 -> {
                piv(t3, bm, 0f, 23f * U, -2.6f * U, rx = 6f + move * 14f + sin(t * 2f) * 2f)
                bx(t3, 0f, -7.5f * U, -0.4f * U, 0f, 0f, 9.4f * U, 15f * U, 0.7f * U, 0f, backC, 1f, 0f)
                piv(t4, t3, 0f, -15f * U, 0f, rx = 4f + move * 10f + sin(t * 3f) * 4f)
                bx(t4, 0f, -2f * U, -0.4f * U, 0f, 0f, 9.6f * U, 4f * U, 0.7f * U, 0f, shadeC(backC, 0.9f), 1f, 0f)
                bx(t4, 0f, -3.8f * U, -0.4f * U, 0f, 0f, 9.8f * U, 0.7f * U, 0.8f * U, 0f, lite(backC, 0.5f), 1f, 0f)
                tb(0f, 5.4f, -1.2f, 9.4f, 1.4f, 2.8f, backC); tb(-2.6f, 5.2f, 2.5f, 1.2f, 1.2f, 0.4f, gold); tb(2.6f, 5.2f, 2.5f, 1.2f, 1.2f, 0.4f, gold)
            }
            2 -> { tb(0f, 0.5f, -3.4f, 6f, 8f, 2.8f, backC); tb(0f, 3.2f, -3.5f, 6.2f, 2.6f, 3f, lite(backC, 0.2f)); tb(-2.6f, 1.5f, 2.45f, 1.1f, 7f, 0.4f, shadeC(backC, 0.8f)); tb(2.6f, 1.5f, 2.45f, 1.1f, 7f, 0.4f, shadeC(backC, 0.8f)) }
            3 -> for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); tb(gf * 3.4f, 3f, -3f, 0.8f, 5.5f, 3.2f, backC, rz = gf * (-(20f + flap * 0.5f))); tb(gf * 4.8f, 1.6f, -3f, 0.8f, 3.2f, 2.4f, lite(backC, 0.3f), rz = gf * (-(36f + flap * 0.6f))) }
            4 -> { for (k in 0..2) { val kf = k.toFloat(); tb(sin(t * 3f - kf) * 0.7f * (0.4f + mv), -4.2f + kf * 0.8f, -3f - kf * 1.8f, 1.7f - kf * 0.2f, 1.7f - kf * 0.2f, 1.9f, if (k == 2) lite(backC, 0.4f) else backC) } }
            5 -> { tb(0.6f, 0.5f, -3.1f, 1f, 13f, 0.6f, steel, rz = 30f); tb(0.6f, 0.5f, -3.1f, 0.4f, 12.4f, 0.7f, lite(steel, 0.4f), rz = 30f); tb(-3.9f, 6.8f, -3.1f, 3.2f, 0.9f, 1f, gold, rz = 30f); tb(-4.6f, 8.2f, -3.1f, 1f, 3.6f, 1f, leather, rz = 30f); tb(-5f, 10f, -3.1f, 1.6f, 1.6f, 1.2f, gold) }
            6 -> for (g in intArrayOf(-1, 1)) { val gf = g.toFloat(); tb(gf * 5.2f, 3.8f, -3.3f, 0.8f, 9.5f, 0.8f, shadeC(backC, 0.7f), rz = gf * (-(28f + flap * 0.6f))); tb(gf * 8.0f, 2.2f, -3.3f, 5f, 6.5f, 0.4f, backC, rz = gf * (-(28f + flap * 0.6f))); tb(gf * 5.4f, -1.2f, -3.3f, 2.6f, 2.4f, 0.4f, shadeC(backC, 0.8f), rz = gf * (-(24f + flap * 0.4f))) }
            7 -> { tb(2.2f, 2.5f, -3.4f, 2.8f, 10f, 2.8f, leather, rz = -14f); tb(2.9f, 8.2f, -3.4f, 0.8f, 2.6f, 0.8f, white, rz = -14f); tb(1.6f, 8.0f, -3.4f, 0.8f, 2.4f, 0.8f, 0xE05555, rz = -14f); tb(0f, 3.2f, 2.45f, 0.8f, 9f, 0.3f, leather, rz = -26f) }
            8 -> { for (k in 0..3) { val kf = k.toFloat(); val sz = 2.6f + (if (k == 3) 0f else kf * 0.5f); tb(sin(t * 3f - kf) * 0.9f * (0.4f + mv), -3.8f + kf * 0.9f, -3.2f - kf * 2.1f, sz, sz, 2.6f, if (k == 3) white else backC) } }
            9 -> { tb(0f, 0f, -3.7f, 7.4f, 9.5f, 3.4f, backC); tb(0f, -3f, -5.5f, 6f, 3.4f, 0.5f, lite(backC, 0.2f)); tb(0f, 3.8f, -3.8f, 7.6f, 2.4f, 3.6f, shadeC(backC, 0.85f)); tb(-2.8f, 1.5f, 2.45f, 1.1f, 7f, 0.4f, shadeC(backC, 0.8f)); tb(2.8f, 1.5f, 2.45f, 1.1f, 7f, 0.4f, shadeC(backC, 0.8f)) }
        }
        // ================= ACESSÓRIOS DE COSTAS: REFORÇO DE MATERIAIS =================
        // Cada tipo ganha componentes de construção, posicionados no dorso e em suas cores.
        lay(4,9)
        when(L[Look.BACK]) {
            1 -> { // capa: bainha dourada dupla e brasão traseiro
                tb(0f,-5.15f,-3.05f,9.1f,0.2f,0.12f,gold)
                tb(0f,-4.85f,-3.06f,8.7f,0.08f,0.1f,lite(backC,0.35f))
                tb(0f,2.5f,-3.12f,1.55f,1.55f,0.12f,shadeC(backC,0.62f),rz=45f)
                tb(0f,2.5f,-3.22f,0.95f,0.95f,0.08f,accentTop,rz=45f)
            }
            2,9 -> { // mochila: bolsos externos, costura, fechos e tiras
                tb(0f,-1.0f,-5.0f,4.3f,2.7f,0.2f,shadeC(backC,0.68f))
                tb(0f,-0.9f,-5.14f,3.75f,2.18f,0.12f,lite(backC,0.1f))
                tb(0f,0.4f,-5.22f,3.6f,0.12f,0.08f,accentTop)
                tb(0f,-1.45f,-5.24f,0.12f,1.65f,0.08f,metalHi)
                for(x in intArrayOf(-2,2)) {
                    tb(x.toFloat(),2.4f,-4.55f,0.24f,4.0f,0.14f,leather)
                    tb(x.toFloat(),2.35f,-4.66f,0.66f,0.62f,0.12f,gold)
                    tb(x.toFloat(),2.35f,-4.74f,0.34f,0.28f,0.08f,accentBottom)
                }
            }
            3,6 -> { // asas: nervuras e filetes das penas
                val wingFlap=sin(t*9f)*(10f+14f*mv)
                for(x in intArrayOf(-1,1)) {
                    tb(x*4f,2.2f,-3.55f,0.18f,7.2f,0.12f,lite(backC,0.35f),rz=x*(-18f-wingFlap*0.45f))
                    for(k in 0..3) tb(x*(2.8f+k*0.4f),3.4f-k*1.5f,-3.68f,1.05f,0.13f,0.1f,shadeC(backC,0.68f),rz=x*(-24f-wingFlap*0.55f))
                }
            }
            5 -> { // espada: abraçadeiras, botão do pomo e acabamento do coldre
                tb(0.6f,3.3f,-3.85f,1.4f,0.26f,0.18f,gold,rz=30f)
                tb(0.6f,0.0f,-3.88f,1.4f,0.26f,0.18f,gold,rz=30f)
                tb(0.6f,5.5f,-3.9f,0.62f,0.62f,0.18f,accentTop,rz=45f)
            }
            7 -> { // aljava: penas coloridas e anéis de fixação
                for(k in 0..2) {
                    tb(2.2f,4.0f-k*2.5f,-5.02f,2.5f,0.16f,0.1f,gold,rz=-14f)
                    tb(2.75f,8.8f-k*0.3f,-4.8f,0.65f,0.7f,0.12f,if(k%2==0) accentTop else accentBottom,rz=-14f)
                }
            }
            8 -> { // cauda: faixas volumétricas e ponta clara
                tb(0f,-4.6f,-7.8f,2.65f,0.45f,1.8f,lite(backC,0.25f))
                tb(0f,-5.0f,-8.15f,2.4f,0.42f,1.4f,white)
            }
        }

    }

}
